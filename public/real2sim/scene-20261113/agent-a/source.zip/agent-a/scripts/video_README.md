# 同长度仿真视频管线

`render_same_duration.py` 在服务器上的 Blender 4.x 环境中加载装配后的 `appearance-scene.blend`，按源视频的 `286.325 s`、`544x960`、`30 fps` 输出时间轴一致的 H.264 视频。若 final-scene 含 `ref260/ref270` 相机，路径会在这两个已求解姿态之间平滑往返；没有锚点时才退回到排除天空/环境大球的场地环绕路径。

当前注册相机由多个断开的 COLMAP 组件组成，因此这只是时间对齐的推断相机路径，不声称恢复了逐帧真实姿态。`--sample-fps 2 --no-interpolate` 会以采样帧保持到 30 fps，适合研究版交付；删除 `--no-interpolate` 可启用 FFmpeg 插帧，但会显著增加 CPU 时间。
