# 同长度仿真视频管线

`render_same_duration.py` 在服务器上的 Blender 4.x 环境中加载装配后的 `appearance-scene.blend`，按源视频的 `286.325 s`、`544x960`、`30 fps` 输出时间轴一致的 H.264 视频。相机路径拟合会排除天空/环境大球，只使用建筑、地面、树和设施几何。

当前注册相机由多个断开的 COLMAP 组件组成，脚本因此使用显式标注的推断环绕路径；它保持时长和画幅用于对照，不声称恢复了逐帧真实姿态。`--sample-fps 2 --no-interpolate` 会以已渲染采样帧保持到 30 fps，适合低成本研究版交付；删除 `--no-interpolate` 可启用 FFmpeg 插帧，但会显著增加 CPU 时间。
