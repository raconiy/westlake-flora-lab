# Agent A appearance refine v3

`refine_appearance_pass.py` 从可编辑的 `appearance-scene.blend` 生成 refined 场景。它保留照片 atlas、UV 与源网格，给建筑、道路、铺装和草坪加图像驱动的 Principled 材质、粗糙度和微表面凹凸；为实测树添加确定性 secondary canopy layers；生成可单独编辑的草簇；并加入标注为 inferred 的低对比度远景 academic wing。

所有随机细节使用 seed `20261114`。远景楼体没有被宣称为实拍恢复。视频管线使用 final-scene 的 `ref260/ref270` 相机做平滑往返，输出源视频相同的 `286.325 s / 544x960 / 30 fps` 时间轴。
