R7.1 source patch. Node >=22.13 and repository dependencies required.
Baseline is public/capture17/yungu-lawn.glb at Git commit 4fcaaa0.
Run: node infra/reconstruction/smooth_leaf_normals.mjs baseline.glb candidate.glb receipt.json
Verify: node infra/reconstruction/verify_leaf_normals.mjs baseline.glb candidate.glb verification.json
Wind is an engineering model, not a measured campus response. The static source does not reconstruct a biological growth history.
