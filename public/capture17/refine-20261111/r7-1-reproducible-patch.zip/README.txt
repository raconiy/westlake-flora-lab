R7.1 patch: apply to the westlake-flora-lab repository, including its dependencies and other reconstruction helpers. Node >=22.13.
Baseline GLB: public/capture17/yungu-lawn.glb at Git commit 4fcaaa0.
Run: node infra/reconstruction/smooth_leaf_normals.mjs baseline.glb candidate.glb receipt.json
Verify: node infra/reconstruction/verify_leaf_normals.mjs baseline.glb candidate.glb verification.json
Use Blender 4.5.15 or a compatible version for RTX 5090, not server /usr/bin/blender 4.0.2.
Turf root count 445454 includes unchanged original111433. Export layout via export_campus_turf.mjs. Material and density are engineering priors.
The static captured GLB does not encode an observed biological growth history.
