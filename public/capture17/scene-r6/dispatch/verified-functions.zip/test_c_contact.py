import math

def check_right_tree(p, approved_closed_band_m, fork_limit_px):
    e = p['evidence']
    x, d, s = e['xmlFinal'], e['dropAndRays'], e['secondaryGeometry']
    rgb = e['materialWorldComparisons']['01']['RGB']
    appearance_gain = rgb['R5MeanAbsLinearRGB'] - rgb['candidateMeanAbsLinearRGB']
    lo, hi = approved_closed_band_m
    assert all(math.isfinite(v) for v in (lo, hi, fork_limit_px))
    assert lo <= hi and fork_limit_px >= 0
    assert x['sourceSha256'] == d['xmlSha256'] == p['release']['xmlSHA256'], 'runtime版本不一致'
    assert x['renderableTreeExportSegmentListSha256'] == s['collisionSegmentsSha256'], '段表不一致'
    assert x['allWorldGeomCount'] == d['worldGeomCount'] == 56
    assert x['givenTreeSegments'] == x['segmentsMatchedInXML'] == d['treeCapsules'] == s['capsuleCount'] == 26, '代理覆盖不完整'
    segs = x['segments']
    assert len(segs) == 26 and {v['segmentIndex'] for v in segs} == set(range(26))
    assert all(len(v['matchingXMLGeoms']) == 1 for v in segs)
    assert len({v['matchingXMLGeoms'][0] for v in segs}) == 26
    bottom = s['lowestClosedCapsuleWorldYM']
    assert math.isfinite(bottom) and lo <= bottom <= hi, '闭合胶囊接地不符合批准区间；整帧改善不能豁免'
    errors = [v['candidatePx'] for v in s['heldoutForkReprojectionPx'].values()]
    assert errors and all(math.isfinite(v) and 0 <= v <= fork_limit_px for v in errors), '对象投影残差超限'
    return {'fullframe01_abs_error_reduction': appearance_gain,
            'right_tree_proxy_and_selected_projection_checks': True,
            'physical_tree_geometry_certified': False}

# 调用示例：check_right_tree(p, (-0.005, 0.005), 60.0)
# 这不是推荐验收政策；它会因-0.1295 m闭合胶囊最低点而失败，
# 即使整帧外观改善、26段覆盖完整且所测分叉残差小于60 px。
