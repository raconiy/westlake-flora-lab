from copy import deepcopy
from math import isfinite

def relative_step_error(reference, observed, floor):
    if not all(isfinite(x) for x in (reference, observed, floor)):
        raise ValueError('finite inputs required')
    return abs(observed-reference)/max(abs(reference), floor) if floor > 0 else -1

def verify_wind(report, baseline):
    rows = {r['hz']: r for r in report['results']}
    refs = {r['hz']: r for r in baseline['results']}
    assert len(report['results']) == len(baseline['results']) == 3
    assert set(rows) == set(refs) == {30, 60, 120}
    for hz, row in rows.items():
        err = row['maxSignedRotationInversionErrorRad']
        assert isfinite(err) and 0 <= err <= 1e-6, 'rotation sign inversion'
        for key, sign in (('positive', 1), ('negative', -1)):
            x, ref = row[key], refs[hz][key]
            fields = ('peakTipCm', 'loadedTipCm', 'settledTipCm',
                      'maxFixedMatrixDelta', 'maxJointLocalSocketMotionM')
            assert all(isfinite(x[k]) and x[k] >= 0 for k in fields)
            assert (x['hz'], x['sign'], x['joints'], x['bases']) == (hz, sign, 65, 13)
            assert x['maxFixedMatrixDelta'] <= 1e-7, 'fixed world matrix'
            assert x['maxJointLocalSocketMotionM'] <= 1e-7, 'joint socket'
            assert x['settledTipCm'] <= 0.01, 'release to calm'
            assert relative_step_error(ref['peakTipCm'], x['peakTipCm'], .01) <= .02
            assert relative_step_error(ref['loadedTipCm'], x['loadedTipCm'], .01) <= 1e-4
        for field in ('peakTipCm', 'loadedTipCm'):
            assert abs(row['positive'][field]-row['negative'][field]) <= 1e-6
    for key in ('positive', 'negative'):
        for field, tolerance in (('peakTipCm', .02), ('loadedTipCm', 1e-4)):
            values = [rows[hz][key][field] for hz in (30, 60, 120)]
            assert relative_step_error(max(values), min(values), .01) <= tolerance
    return {'status': 'aggregate-regression-pass', 'sustainedAngle': 'unmeasured'}

PEAK = [(6.826017055907761, 6.826017055907767),
        (6.854195876444645, 6.854195876444634),
        (6.8868648740406115, 6.886864874040607)]
LOADED = [(4.920237978028343, 4.920237978028339),
          (4.920237978028343, 4.920237978028339),
          (4.920237978028348, 4.920237978028345)]
def supplied_report(sha):
    rows = []
    for i, hz in enumerate((30, 60, 120)):
        row = {'hz': hz, 'maxSignedRotationInversionErrorRad': 2.9802322387695312e-08}
        for j, key in enumerate(('positive', 'negative')):
            row[key] = dict(hz=hz, sign=1 if j == 0 else -1, joints=65, bases=13,
                peakTipCm=PEAK[i][j], loadedTipCm=LOADED[i][j], settledTipCm=0,
                maxFixedMatrixDelta=0, maxJointLocalSocketMotionM=0)
        rows.append(row)
    return {'glbSha256': sha, 'results': rows}

if __name__ == '__main__':
    old = supplied_report('ab5db9bc31ccd5e5de9251fe790b3d1f42232cfccb83ead41e3e58ede8253e96')
    new = supplied_report('56f96713159bf62a04a133d0591dc254f733c0da69e258365868116c38ba8030')
    assert relative_step_error(0, .01, .01) == 1 and relative_step_error(1, 2, 0) == -1
    print(verify_wind(new, old))
    for scope, field, bad in [(None, 'maxSignedRotationInversionErrorRad', 1e-4),
            ('positive', 'maxFixedMatrixDelta', 1e-5), ('positive', 'sign', -1),
            ('positive', 'maxJointLocalSocketMotionM', 1e-5),
            ('positive', 'settledTipCm', .02), ('positive', 'loadedTipCm', 5.1),
            ('positive', 'peakTipCm', 7.5)]:
        changed = deepcopy(new)
        row = changed['results'][0]
        (row if scope is None else row[scope])[field] = bad
        try:
            verify_wind(changed, old)
        except AssertionError:
            continue
        raise AssertionError('mutation was not rejected: ' + field)
