import numpy as np


def guard_crown(views, origins=None, rays=None, wood_points=None,
                current=None, angular_error=None):
    out = dict(keep=None, fork=None, metrics={}, reason='缺少注册分割')
    if views is None:
        return out
    if set(views) != {'01', '06'}:
        raise ValueError('only training cameras 01/06')
    keep, outline_ok = None, True
    for name in ('01', '06'):
        v = views[name]
        k, h, b, e, w, c, valid = [np.asarray(v[s]) for s in
            ('known', 'holes', 'wood', 'envelope', 'wood_after', 'leaf_cover', 'valid')]
        if (k.ndim != 2 or not k.size or any(x.dtype != np.bool_ for x in
                (k, h, b, e, w, c, valid)) or
                any(x.shape != k.shape for x in (h, b, e, w)) or
                c.ndim != 3 or c.shape[1:] != k.shape or valid.shape != (len(c),)):
            raise ValueError(name + ': invalid registered boolean evidence')
        local = valid & ~np.any(c[:, k & (h | b | ~e)], axis=1)
        if keep is not None and keep.shape != local.shape:
            raise ValueError('candidate identities/count must match')
        keep = local.copy() if keep is None else keep & local
        outline_ok &= bool((k & b).any() and np.array_equal(w[k], b[k]))
    out.update(keep=keep, reason='缺少分叉三维支持；不得移动')
    if any(x is None for x in (origins, rays, wood_points, current, angular_error)):
        return out
    C, d, T, old = [np.asarray(x, float) for x in (origins, rays, wood_points, current)]
    err = float(angular_error)
    if (C.shape != (2, 3) or d.shape != (2, 3) or old.shape != (3,) or
            T.ndim != 2 or T.shape[1] != 3 or
            not all(np.isfinite(x).all() for x in (C, d, T, old)) or
            not np.isfinite(err) or not 0 < err < np.pi / 2):
        raise ValueError('invalid metric fork evidence')
    length = np.linalg.norm(d, axis=1)
    if np.any(length < 1e-12):
        return dict(out, reason='零方向射线')
    d = d / length[:, None]
    angle = np.arccos(np.clip(abs(d[0] @ d[1]), 0, 1))
    Q = np.eye(3)[None] - d[:, :, None] * d[:, None, :]
    A = Q.sum(axis=0)
    ev = np.linalg.eigvalsh(A)
    cond = np.inf if ev[0] <= 0 else ev[-1] / ev[0]
    out['metrics'].update(angle_deg=float(np.degrees(angle)), condition=float(cond))
    if angle < np.deg2rad(5) or cond > 1000:
        return dict(out, reason='病态射线；拒绝求交和移动')
    x = np.linalg.solve(A, np.einsum('nij,nj->i', Q, C))
    depth = np.sum((x - C) * d, axis=1)
    gap = np.linalg.norm(np.einsum('nij,nj->ni', Q, x - C), axis=1)
    uncertainty = np.linalg.norm(gap + abs(depth) * np.tan(err)) / np.sqrt(ev[0])
    local = T[np.linalg.norm(T - x, axis=1) <= 0.10]
    spread = np.linalg.svd(local - local.mean(axis=0), compute_uv=False)[1] if len(local) >= 3 else 0.
    move = np.linalg.norm(x - old)
    out['metrics'].update(ray_gap_m=float(gap.max()), uncertainty_m=float(uncertainty),
                          support_count=len(local), movement_m=float(move))
    accepted = (outline_ok and np.all(depth > 0) and gap.max() <= .02 and
                uncertainty <= .02 and len(local) >= 3 and
                spread > max(.01, 2 * uncertainty) and move > 3 * uncertainty)
    return dict(out, fork=x if accepted else None,
                reason='允许提交分叉候选作后续验收' if accepted else '支持或轮廓不足；保持分叉不变')


# 合成单元测试，不是照片分割或实测射线。
z = np.zeros((1, 1), dtype=bool)
o = ~z
v = dict(known=o, holes=o, wood=z, envelope=o, wood_after=z,
         leaf_cover=o[None], valid=np.array([True]))
assert not guard_crown({'01': v, '06': dict(v, known=z)})['keep'][0]
assert guard_crown({'01': dict(v, known=z), '06': dict(v, known=z)})['keep'][0]

# 实际源码观测示例：只能登记UV；没有相机与分割，必须拒绝实际修改。
observed_uv = np.array([[562., 267.], [612., 142.]])
assert observed_uv.shape == (2, 2)
assert guard_crown(None)['keep'] is None
assert np.isclose(1 - .84, .16)  # 实际fit的减叶下限不是硬否决。
