import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const [repo,asset,output]=process.argv.slice(2);
const THREE=await import(pathToFileURL(repo+'/node_modules/three/build/three.module.js'));
const {createCaptureWind}=await import(pathToFileURL(repo+'/lib/capture-wind.ts'));
const data=fs.readFileSync(asset);assert.equal(data.readUInt32LE(0),0x46546c67);
const doc=JSON.parse(data.subarray(20,20+data.readUInt32LE(12)));
function run(hz,sign){
  const nodes=doc.nodes.map(n=>{
    const object=new THREE.Object3D();object.name=n.name??'';object.userData=n.extras??{};
    if(n.matrix){object.matrix.fromArray(n.matrix);object.matrix.decompose(object.position,object.quaternion,object.scale);}
    else{if(n.translation)object.position.fromArray(n.translation);if(n.rotation)object.quaternion.fromArray(n.rotation);if(n.scale)object.scale.fromArray(n.scale);}
    return object;
  });
  doc.nodes.forEach((n,i)=>n.children?.forEach(c=>nodes[i].add(nodes[c])));
  const world=new THREE.Group();for(const id of doc.scenes[doc.scene??0].nodes)world.add(nodes[id]);
  const bases=nodes.filter(o=>o.userData.root_anchored||o.userData.asset_class==='fixed path luminaire');
  const joints=nodes.filter(o=>o.userData.wind_joint===true);
  const d=createCaptureWind(world);assert.equal(d.stats.branchCount,joints.length);assert.ok(bases.length>=13&&joints.length>=40);world.updateMatrixWorld(true);
  const fixed=bases.map(o=>[...o.matrixWorld.elements]);const sockets=joints.map(o=>o.position.clone());const quats=joints.map(o=>o.quaternion.clone());
  let maxFixedMatrixDelta=0,maxJointLocalSocketMotionM=0,peakTipCm=0,steady=null;
  for(let i=0;i<hz*22;i++){
    const st=d.step(1/hz,i<hz*4?sign*6:0,0);peakTipCm=Math.max(peakTipCm,st.maxTipCm);
    if(i===hz*4-1){steady={tipCm:st.maxTipCm,quaternions:joints.map((j,k)=>quats[k].clone().invert().multiply(j.quaternion).toArray())};}
    if(i%hz===0||i===hz*22-1){world.updateMatrixWorld(true);bases.forEach((o,k)=>o.matrixWorld.elements.forEach((v,s)=>{maxFixedMatrixDelta=Math.max(maxFixedMatrixDelta,Math.abs(v-fixed[k][s]));}));joints.forEach((o,k)=>{maxJointLocalSocketMotionM=Math.max(maxJointLocalSocketMotionM,o.position.distanceTo(sockets[k]));});}
  }
  return {hz,sign,joints:joints.length,bases:bases.length,peakTipCm,settledTipCm:d.stats.maxTipCm,loadedTipCm:steady.tipCm,maxFixedMatrixDelta,maxJointLocalSocketMotionM,quats:steady.quaternions};
}
const result=[];
for(const h of [30,60,120]){
 const plus=run(h,1),minus=run(h,-1);
 const antiError=Math.max(...plus.quats.map((q,i)=>new THREE.Quaternion().fromArray(q).invert().angleTo(new THREE.Quaternion().fromArray(minus.quats[i]))));
 delete plus.quats;delete minus.quats;result.push({hz:h,positive:plus,negative:minus,maxSignedRotationInversionErrorRad:antiError});
}
fs.writeFileSync(output,JSON.stringify({glbSha256:crypto.createHash('sha256').update(data).digest('hex'),method:'Shipped GLB hierarchy × product wind solver. At 30,60,120 fps apply signed +/-6 m/s for 4 s then release for 18 s. Check fixed world matrices throughout, wind-joint local socket, sign inversion and frame-rate sensitivity. Engineering model, not real wind capture.',results:result},null,2));
