import hashlib, json, math, struct
from pathlib import Path
from copy import deepcopy
from tempfile import TemporaryDirectory


def outside_contact_band(height, lower, upper):
    M = 1.7976931348623157e308
    return max(lower-height, height-upper, 0) if (
        -M <= lower <= upper <= M and abs(height) <= M) else -1


def audit(base, trials, owned, assets):
    def need(ok, message):
        if not ok:
            raise ValueError(message)
    names = {'paving', 'lamp', 'merged'}
    need(set(trials) == set(owned) == names, '试验不完整')
    need(set(assets) == names | {'base'}, '文件不完整')
    need(bool(owned['paving']) and bool(owned['lamp']), '空修改范围')
    need(not owned['paving'] & owned['lamp'], '两个单改范围重叠')
    need(owned['merged'] == owned['paving'] | owned['lamp'], '合并范围错误')
    hashes = []
    for name, a in assets.items():
        blob = Path(a['path']).read_bytes()
        need(len(blob) >= 12 and struct.unpack('<4sII', blob[:12]) ==
             (b'glTF', 2, len(blob)), '不是匹配长度的 GLB2')
        digest = hashlib.sha256(blob).hexdigest()
        need(digest == a['sha256'], name + ': 文件与侧车不匹配')
        hashes.append(digest)
    need(len(set(hashes)) == 4, '基线、两个单改和合并文件必须互异')
    initial = assets['base']['state']
    for name in names:
        state = assets[name]['state']
        need(state.keys() == initial.keys(), '对象清单变化或缺失')
        need({k for k in initial if state[k] != initial[k]} == owned[name],
             name + ': 不是所声明的单改/合并范围')
    for k in initial:
        source = 'paving' if k in owned['paving'] else 'lamp' if k in owned['lamp'] else 'base'
        need(assets['merged']['state'][k] == assets[source]['state'][k], '合并内容不一致')
    result = {}
    need(bool(base), '缺少基线相机')
    for name, frames in trials.items():
        need(frames.keys() == base.keys(), '相机集合不一致')
        result[name] = {}
        for cid, ref in base.items():
            frame, c = frames[cid], ref['camera']
            need(cid in {'01', '06'} and c['id'] == cid, '超出适配相机范围')
            need(c['size'] == [1024, 768] and c['projection'] and c['pipeline'], '相机证据不全')
            need(len(c['K']) == 9 and len(c['world_to_camera']) == 16 and
                 all(math.isfinite(v) for v in c['K'] + c['world_to_camera']), '相机矩阵无效')
            need(frame['camera'] == c, '相机或渲染管线不是精确配对')
            need(frame['samples'].keys() == ref['samples'].keys(), '标签缺失须显式标记')
            for (obj, mat), a in ref['samples'].items():
                if obj in owned[name]:
                    continue
                b = frame['samples'][(obj, mat)]
                statuses = (a['status'], b['status'])
                need(all(s in {'measured', 'filled_shadow', 'missing_segment'} for s in statuses), '未知标签状态')
                row = {'camera': cid, 'object': obj, 'statuses': statuses, 'rgb_mae': None}
                if statuses == ('measured', 'measured'):
                    need(bool(a['support_sha256']) and a['support_sha256'] == b['support_sha256'], '比较支持不同')
                    need(len(a['rgb']) == len(b['rgb']) == 3 and
                         all(math.isfinite(v) and 0 <= v <= 255 for v in a['rgb'] + b['rgb']), 'RGB 无效')
                    row['rgb_mae'] = sum(abs(x-y) for x, y in zip(a['rgb'], b['rgb'])) / 3
                result[name].setdefault(mat, []).append(row)
    return result


if __name__ == '__main__':
    h = -0.02808620723817601  # 已给碰撞代理测量
    assert outside_contact_band(h, -.030, 0) == 0
    assert math.isclose(outside_contact_band(h, -.005, .005), .02308620723817601)
    assert outside_contact_band(0, 1, 0) == outside_contact_band(float('nan'), 0, 1) == -1
    # 以下相机、材质 ID、变化指纹均为合成测试；RGB 取自已给 R5 杆体样本。
    c = dict(id='01', size=[1024, 768], projection='perspective', pipeline='synthetic-8bit',
             K=[1,0,0,0,1,0,0,0,1], world_to_camera=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1])
    base = {'01': {'camera': c, 'samples': {('lamp', 'synthetic-pole-material'):
            dict(status='measured', rgb=[18.5,20.5,15.0], support_sha256='0'*64)}}}
    owned = {'paving': {'paving'}, 'lamp': {'lamp'}, 'merged': {'paving', 'lamp'}}
    trials = {n: deepcopy(base) for n in owned}
    trials['paving']['01']['samples'][('lamp', 'synthetic-pole-material')]['rgb'][0] += 1
    with TemporaryDirectory() as directory:
        assets = {}
        for name, p, l in [('base',0,0), ('paving',1,0), ('lamp',0,1), ('merged',1,1)]:
            state = {'paving': str(p), 'lamp': str(l)}
            payload = json.dumps({'asset': {'version': '2.0'}, 'extras': state}).encode()
            payload += b' ' * (-len(payload) % 4)
            blob = struct.pack('<4sII', b'glTF', 2, 20+len(payload)) + struct.pack('<I4s', len(payload), b'JSON') + payload
            path = Path(directory) / (name + '.glb'); path.write_bytes(blob)
            assets[name] = dict(path=path, sha256=hashlib.sha256(blob).hexdigest(), state=state)
        report = audit(base, trials, owned, assets)
        assert math.isclose(report['paving']['synthetic-pole-material'][0]['rgb_mae'], 1/3)
        bad = deepcopy(assets); bad['merged'] = bad['lamp']
        try:
            audit(base, trials, owned, bad)
        except ValueError:
            pass
        else:
            raise AssertionError('不得把单改文件当合并文件')
        bad = deepcopy(trials); bad['paving']['01']['camera']['world_to_camera'][3] = .01
        try:
            audit(base, bad, owned, assets)
        except ValueError:
            pass
        else:
            raise AssertionError('必须拒绝相机不精确配对')
