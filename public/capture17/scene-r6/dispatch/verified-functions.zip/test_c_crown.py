def assert_hard_gaps(views, keep):
    assert set(views) == {'01', '03', '06', '09'}
    assert len(keep) > 0 and all(type(k) is bool for k in keep)
    for v in views.values():
        assert v['reviewed'] is True
        assert v['full_potential_cover'] is True
        known, holes = v['known'], v['holes']
        cover, valid = v['leaf_cover'], v['valid']
        assert len(known) == len(holes) > 0
        assert len(cover) == len(valid) == len(keep)
        assert all(type(x) is bool for x in known)
        assert all(type(x) is bool for x in holes)
        assert all(type(x) is bool for x in valid)
        for i, retained in enumerate(keep):
            assert len(cover[i]) == len(known)
            assert all(type(x) is bool for x in cover[i])
            if retained:
                assert valid[i]
                assert not any(k and h and p for k, h, p in zip(known, holes, cover[i]))
