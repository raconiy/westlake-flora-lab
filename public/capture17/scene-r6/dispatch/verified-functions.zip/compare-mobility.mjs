import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const [repo,oldAsset,newAsset,out]=process.argv.slice(2);
const THREE=await import(pathToFileURL(repo+'/node_modules/three/build/three.module.js'));
const {createCaptureWind}=await import(pathToFileURL(repo+'/lib/capture-wind.ts'));
function measure(path){
  const data=fs.readFileSync(path);if(data.readUInt32LE(0)!==0x46546c67||data.readUInt32LE(8)!==data.length)throw Error('GLB2 byte length');
  const doc=JSON.parse(data.subarray(20,20+data.readUInt32LE(12)));
  const graph=doc.nodes.map(n=>{const o=new THREE.Object3D();o.name=n.name||'';o.userData=n.extras||{};if(n.matrix){o.matrix.fromArray(n.matrix);o.matrix.decompose(o.position,o.quaternion,o.scale);}else{if(n.translation)o.position.fromArray(n.translation);if(n.rotation)o.quaternion.fromArray(n.rotation);if(n.scale)o.scale.fromArray(n.scale);}return o;});
  doc.nodes.forEach((n,i)=>n.children?.forEach(c=>graph[i].add(graph[c])));
  const root=new THREE.Group();for(const i of doc.scenes[doc.scene??0].nodes)root.add(graph[i]);root.updateMatrixWorld(true);
  const dynamics=createCaptureWind(root),fixed=graph.filter(n=>n.userData.root_anchored||n.userData.asset_class==='fixed path luminaire'),joint=graph.filter(n=>n.userData.wind_joint===true);if(new Set(joint.map(n=>n.name)).size!==joint.length||joint.length!==dynamics.stats.branchCount)throw Error('Unusable/doubled exported joint');
  const staticStart=fixed.map(n=>n.matrixWorld.clone()),initial=joint.map(n=>n.quaternion.clone()),sockets=joint.map(n=>n.position.clone());const phases={};let maxBaseDrift=0,maxSocketDrift=0;
  for(const [name,seconds,speed] of [['positive',4,6],['release1',18,0],['negative',4,-6],['release2',18,0]]){
    for(let i=0;i<60*seconds;i++)dynamics.step(1/60,speed,0);
    root.updateMatrixWorld(true);
    const d=joint.map((n,i)=>initial[i].clone().invert().multiply(n.quaternion).normalize());phases[name]=d;
    fixed.forEach((n,i)=>n.matrixWorld.elements.forEach((v,k)=>{maxBaseDrift=Math.max(maxBaseDrift,Math.abs(v-staticStart[i].elements[k]));}));
    joint.forEach((n,i)=>{maxSocketDrift=Math.max(maxSocketDrift,n.position.distanceTo(sockets[i]));});
  }
  const map=new Map();for(const [i,n] of joint.entries()){map.set(n.name,{pos:phases.positive[i],negative:phases.negative[i],release:Math.max(phases.release1[i].angleTo(new THREE.Quaternion()),phases.release2[i].angleTo(new THREE.Quaternion())),inversion:phases.positive[i].clone().invert().angleTo(phases.negative[i])});}
  const leaves=graph.filter(n=>Number(n.userData.physical_blades)>0);
  return {sha256:createHash('sha256').update(data).digest('hex'),joints:map,anchors:fixed.map(n=>n.name),maxBaseDrift,maxSocketDrift,leafMeshes:leaves.length,attachedLeafMeshes:leaves.filter(n=>n.parent?.userData?.wind_joint===true).length};
}
const old=measure(oldAsset),nu=measure(newAsset),common=[...old.joints.keys()].filter(k=>nu.joints.has(k)),added=[...nu.joints.keys()].filter(k=>!old.joints.has(k)),removed=[...old.joints.keys()].filter(k=>!nu.joints.has(k));const angleChanges=common.map(k=>({name:k,rad:old.joints.get(k).pos.angleTo(nu.joints.get(k).pos)})).sort((a,b)=>b.rad-a.rad);
function brief(x){return {sha256:x.sha256,joints:x.joints.size,anchorNames:x.anchors.sort(),maxBaseMatrixDrift:x.maxBaseDrift,maxLocalSocketDriftM:x.maxSocketDrift,leafMeshes:x.leafMeshes,attachedLeafMeshes:x.attachedLeafMeshes,maxReleaseAngleRad:Math.max(...[...x.joints.values()].map(v=>v.release)),maxSignedInversionErrorRad:Math.max(...[...x.joints.values()].map(v=>v.inversion))};}
const result={method:'Product solver and named GLB nodes, 60 Hz. +6 m/s 4 s, zero 18 s, -6 m/s 4 s, zero 18 s. Fixed transforms, local sockets, signed axis response and calm. Names newly added or removed reported individually; change to preexisting beam rest/response measured as local rest-relative quaternion absolute angle.',baseline:brief(old),candidate:brief(nu),sharedJointCount:common.length,addedJointNames:added,removedJointNames:removed,sharedWithResponseChanged:[...angleChanges].filter(r=>r.rad>1e-6)};fs.writeFileSync(out,JSON.stringify(result,null,2));
