import unittest
from infra.reconstruction.lamp_fixtures import (
    edge_width, paired_widths, profile_spans)


def rectangle(left, right):
    return [[left <= x < right for x in range(24)] for y in range(24)]


class FixtureTests(unittest.TestCase):
    def test_projected_width_and_pairing(self):
        clear = [[True] * 24 for _ in range(24)]
        photo = rectangle(10, 14)
        render = rectangle(8, 16)
        sections = {1.0: ((12, 12), (0, 1))}
        result = paired_widths(photo, clear, render, clear, sections, sections,
                               half_window=8)
        self.assertEqual(result['photo_width_px'], 4.0)
        self.assertEqual(result['render_width_px'], 8.0)
        self.assertEqual(len(result['accepted_sections']), 1)

    def test_occlusion_is_not_a_narrower_shaft(self):
        clear = [[True] * 24 for _ in range(24)]
        clear[12][11] = False
        self.assertIsNone(edge_width(rectangle(10, 14), clear,
                                      (12, 12), (0, 1), half_window=8))

    def test_underresolved_and_clipped(self):
        clear = [[True] * 24 for _ in range(24)]
        self.assertIsNone(edge_width(rectangle(11, 13), clear,
                                      (12, 12), (0, 1), half_window=8))
        self.assertIsNone(edge_width(clear, clear, (12, 12), (0, 1),
                                      half_window=8))

    def test_waist_remains_a_section_boundary(self):
        # Synthetic test geometry, not a measured lamp profile.
        p = [(0, 0.10), (1, 0.04), (2, 0.10)]
        self.assertEqual(profile_spans(p), [p[:2], p[1:]])
        with self.assertRaises(ValueError):
            profile_spans([(0, 0.1), (0, 0.2)])


if __name__ == '__main__':
    unittest.main()
