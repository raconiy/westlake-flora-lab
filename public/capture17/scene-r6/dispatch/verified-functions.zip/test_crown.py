import unittest
import numpy as np
from infra.reconstruction.crown_visibility import (
    visibility_targets, assert_shoot_bound)


class VisibilityTests(unittest.TestCase):
    def views(self):
        P = np.array([[1., 0., 0., 0.],
                      [0., 1., 0., 0.],
                      [0., 0., 1., 0.]])
        return {name: dict(P=P.copy(),
                           envelope=np.ones((20, 20), dtype=bool),
                           known=np.ones((20, 20), dtype=bool),
                           protect=np.zeros((20, 20), dtype=bool))
                for name in ('01', '06')}

    def select(self, p, views):
        return visibility_targets(p, views, radius=.01,
                                  voxel=.22, seed=17)

    def test_hole_and_determinism(self):
        views = self.views()
        views['01']['protect'][5, 5] = True
        p = np.array([[5., 5., 1.], [12., 12., 1.], [12., 12., 1.]])
        a = self.select(p, views)
        np.testing.assert_array_equal(a, [[12., 12., 1.]])
        np.testing.assert_array_equal(a, self.select(p[::-1], views))

    def test_unknown_is_not_evidence(self):
        views = self.views()
        for v in views.values():
            v['known'][:] = False
        self.assertEqual(len(self.select([[5., 5., 1.]], views)), 0)

    def test_envelope_veto(self):
        views = self.views()
        views['06']['envelope'][12, 12] = False
        self.assertEqual(len(self.select([[12., 12., 1.]], views)), 0)

    def test_holdout_and_geometry_fail_closed(self):
        views = self.views()
        views['13'] = views['01']
        with self.assertRaises(ValueError):
            self.select([[5., 5., 1.]], views)
        with self.assertRaises(ValueError):
            assert_shoot_bound([0., 0., 0.], [[.02, 0., 0.]], .01)


if __name__ == '__main__':
    unittest.main()
