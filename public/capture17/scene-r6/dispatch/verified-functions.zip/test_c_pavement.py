import math

def assert_withheld_positions(r):
    rows = [x for xs in r['evidence']['notches'].values() for x in xs]
    def finite(v):
        return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)
    triples = [x['position'] for x in rows
               if len(x['position']) == 3 and all(finite(v) for v in x['position'])]
    delta = [abs(o - p) - abs(n - p) for p, o, n in triples]
    assert (len(rows) > 0 and len(triples) == len(rows)
            and all(v >= -1e-12 for v in delta)), (
        'paired', len(triples), 'total', len(rows), 'signed_improvements_m', delta)

# 调用：assert_withheld_positions(r)
