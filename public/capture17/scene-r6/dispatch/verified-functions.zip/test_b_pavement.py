import numpy as np


def estimate_joint_profiles(d, t, y, support, missing, filled_shadow, split, ids,
                            *, half, eps, max_gap, pos_tol, center=4.75):
    d, t, y = [np.asarray(a, float) for a in (d, t, y)]
    support, missing, shadow = [np.asarray(a, bool) for a in (support, missing, filled_shadow)]
    split = np.asarray(split)
    if d.ndim != 1 or t.ndim != 1 or y.shape != (len(t), 3, len(d)):
        raise ValueError('Expected world d, world t, and [transect,3,d] luminance')
    if any(a.shape != y.shape for a in (support, missing, shadow)):
        raise ValueError('Separate masks must match luminance')
    if not np.isfinite(d).all() or not np.isfinite(t).all() or not np.all(np.diff(d) > 0):
        raise ValueError('Finite coordinates and strictly increasing d required')
    if split.shape != t.shape or not np.isin(split, ['train', 'withheld']).all():
        raise ValueError('Explicit training/withheld labels required')
    if len(ids) != len(t) or len(set(ids)) != len(t) or len(set(t)) != len(t):
        raise ValueError('Repeated transects may leak between partitions')
    if not all(np.isfinite(v) and v > 0 for v in (half, eps, max_gap, pos_tol)) or not np.isfinite(center):
        raise ValueError('Lock finite positive estimator parameters before evaluation')
    u = d - center; window = abs(u) <= 3 * half; notch = abs(u) <= half
    shoulder = window & ~notch
    if min(np.sum(shoulder & (u < 0)), np.sum(shoulder & (u > 0))) < 2 or notch.sum() < 3:
        raise ValueError('Need two shoulders and a resolved notch')
    rows = []
    for i in range(len(t)):
        common = (support[i] & ~missing[i] & ~shadow[i] & np.isfinite(y[i]) & (y[i] > 0)).all(axis=0) & window
        r = dict(id=ids[i], t=float(t[i]), split=str(split[i]), support=common,
                 profile=np.full((3, len(d)), np.nan), eligible=False, reason='missing_support',
                 missing=int(missing[i][:, window].sum()), filled_shadow=int(shadow[i][:, window].sum()),
                 contrast_improvement=None, position_improvement=None)
        rows.append(r)
        if not common[window].all():
            continue
        baseline = np.array([np.polyval(np.polyfit(u[shoulder], v[shoulder], 1), u) for v in y[i]])
        if not (baseline[:, window] > 0).all():
            r['reason'] = 'nonpositive_baseline'; continue
        p = np.full_like(baseline, np.nan); p[:, window] = 1 - y[i][:, window] / baseline[:, window]
        peaks = np.flatnonzero(notch)[np.argmax(p[:, notch], axis=1)]
        contrast = np.maximum(0, p[np.arange(3), peaks]); r['notch_contrast'] = contrast
        if contrast[0] <= eps:
            r['reason'] = 'near_zero_reference'; continue
        position = np.where(contrast > eps, d[peaks], np.nan)
        r.update(profile=p, position=position, eligible=True, reason='ok',
                 contrast_improvement=float(abs(contrast[0]-contrast[1])-abs(contrast[0]-contrast[2])))
        if np.isfinite(position).all():
            r['position_improvement'] = float(abs(position[0]-position[1])-abs(position[0]-position[2]))
    links = []
    for group in ('train', 'withheld'):
        ordered = sorted((r for r in rows if r['split'] == group), key=lambda r: r['t'])
        for a, b in zip(ordered, ordered[1:]):
            state = gain = None
            if a['eligible'] and b['eligible'] and b['t']-a['t'] <= max_gap:
                state = ((a['notch_contrast'] > eps) & (b['notch_contrast'] > eps) & (abs(a['position']-b['position']) <= pos_tol)).astype(int)
                gain = abs(int(state[0])-int(state[1]))-abs(int(state[0])-int(state[2]))
            links.append(dict(split=group, ids=(a['id'], b['id']), continuity=state, improvement=gain))
    return dict(train=[r for r in rows if r['split']=='train'], withheld=[r for r in rows if r['split']=='withheld'], links=links)


if __name__ == '__main__':
    d = np.linspace(4.55, 4.95, 81); t = [0, .1, 1, 1.1]
    f = np.maximum(0, 1-abs(d-4.75)/.025)
    y = np.tile(.2*(1-np.array([.2, .05, .18])[:, None]*f), (4, 1, 1))
    y[:, 1] = .2*(1-.05*np.maximum(0, 1-abs(d-4.76)/.025))
    support = np.ones_like(y, bool); zero = np.zeros_like(y, bool)
    def run(a=y, miss=zero, shade=zero):
        return estimate_joint_profiles(d, t, a, support, miss, shade,
            ['train', 'train', 'withheld', 'withheld'], list('abcd'),
            half=.05, eps=.01, max_gap=.15, pos_tol=.02)
    r = run(); q = r['withheld'][0]
    assert np.isclose(q['contrast_improvement'], .13) and np.isclose(q['position_improvement'], .01)
    assert np.isclose(run(y*2)['withheld'][0]['contrast_improvement'], .13)
    flat = y.copy(); flat[:, 0] = .2
    assert np.isnan(run(flat)['withheld'][0]['profile']).all()
    m = zero.copy(); m[2, 0, 40] = True
    q = run(miss=m)['withheld'][0]
    assert not q['eligible'] and q['missing'] == 1 and q['filled_shadow'] == 0
    q = run(shade=m)['withheld'][0]
    assert not q['eligible'] and q['missing'] == 0 and q['filled_shadow'] == 1
    broken = y.copy(); broken[3, 1] = .2
    assert run(broken)['links'][-1]['improvement'] == 1
    assert abs((abs(.1857204-.4973527)-abs(.1857204-.1799325))-.3058444) < 1e-12
