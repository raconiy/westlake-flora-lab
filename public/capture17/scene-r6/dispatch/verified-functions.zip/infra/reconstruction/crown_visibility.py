import hashlib
import numpy as np


def visibility_targets(candidates, views, *, radius, voxel, seed):
    """返回中心；每个实际生成叶簇必须完全位于radius球内。"""
    p = np.asarray(candidates, dtype=float)
    if p.ndim != 2 or p.shape[1] != 3 or not np.isfinite(p).all():
        raise ValueError('candidates must be finite Nx3')
    if not (np.isfinite(radius) and radius > 0 and
            np.isfinite(voxel) and voxel > 0):
        raise ValueError('positive finite radius/voxel required')
    if set(views) != {'01', '06'}:
        raise ValueError('only training cameras 01 and 06 are allowed')
    checked = []
    for name in ('01', '06'):
        v = views[name]
        P = np.asarray(v['P'], dtype=float)
        env = np.asarray(v['envelope'])
        known = np.asarray(v['known'])
        protect = np.asarray(v['protect'])
        if P.shape != (3, 4) or not np.isfinite(P).all():
            raise ValueError(name + ': invalid projection')
        if (env.ndim != 2 or min(env.shape) == 0 or
                any(a.shape != env.shape or a.dtype != np.bool_
                    for a in (env, known, protect))):
            raise ValueError(name + ': boolean masks must have equal HxW')
        checked.append((P, env, known, protect))

    # 先按体素和坐标排序，避免输入排列或随机数调用顺序改变结果。
    cells = np.floor(p / voxel)
    order = sorted(range(len(p)),
                   key=lambda i: tuple(cells[i]) + tuple(p[i]))
    unique = []
    last = None
    for i in order:
        cell = tuple(cells[i])
        if cell != last:
            unique.append(p[i].copy())
            last = cell

    kept = []
    for center in unique:
        rejected = False
        supported = False
        for P, env, known, protect in checked:
            q = P[:, :3] @ center + P[:, 3]
            # 齐次分子/分母的区间运算保守包住整个三维球。
            delta = radius * np.linalg.norm(P[:, :3], axis=1)
            zlo, zhi = q[2] - delta[2], q[2] + delta[2]
            if zlo <= 0:
                rejected = True
                break
            bounds = []
            for axis in (0, 1):
                values = [(q[axis] + s * delta[axis]) / z
                          for s in (-1, 1) for z in (zlo, zhi)]
                bounds.append((min(values), max(values)))
            x0, x1 = int(np.floor(bounds[0][0])), int(np.ceil(bounds[0][1]))
            y0, y1 = int(np.floor(bounds[1][0])), int(np.ceil(bounds[1][1]))
            h, w = env.shape
            if x1 < 0 or y1 < 0 or x0 >= w or y0 >= h:
                continue
            xa, xb = max(0, x0), min(w - 1, x1)
            ya, yb = max(0, y0), min(h - 1, y1)
            sl = np.s_[ya:yb + 1, xa:xb + 1]
            k = known[sl]
            # 只在可靠可见像素上施加外包络、孔洞和木质轮廓约束。
            if np.any(k & ((~env[sl]) | protect[sl])):
                rejected = True
                break
            fully_in_frame = x0 >= 0 and y0 >= 0 and x1 < w and y1 < h
            supported |= bool(fully_in_frame and np.all(k))
        # 至少一个训练视图完整支持该投影足迹；未知背面不凭空填充。
        if not rejected and supported:
            kept.append(center)

    def stable_key(center):
        payload = (str(int(seed)).encode('ascii') + b':' +
                   np.asarray(center, dtype='<f8').tobytes())
        return hashlib.sha256(payload).digest(), tuple(center)

    kept.sort(key=stable_key)
    return np.asarray(kept, dtype=float).reshape(-1, 3)


def assert_shoot_bound(center, vertices, radius):
    """叶簇实例化后调用；vertices须包含其全部几何且处于目标坐标系。"""
    c = np.asarray(center, dtype=float)
    v = np.asarray(vertices, dtype=float)
    if (c.shape != (3,) or not np.isfinite(c).all() or
            v.ndim != 2 or v.shape[1] != 3 or len(v) == 0 or
            not np.isfinite(v).all() or
            not np.isfinite(radius) or radius <= 0):
        raise ValueError('invalid realized shoot geometry')
    if np.any(np.linalg.norm(v - c, axis=1) > radius):
        raise ValueError('realized shoot exceeds visibility-tested bound')
