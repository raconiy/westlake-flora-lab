import math
from statistics import median


def checked_profile(profile):
    p = [(float(h), float(r)) for h, r in profile]
    if len(p) < 2 or any(not math.isfinite(v) for pair in p for v in pair):
        raise ValueError('Profile needs at least two finite rings')
    if any(r < 0 for h, r in p):
        raise ValueError('Negative radius')
    if any(a[0] >= b[0] for a, b in zip(p, p[1:])):
        raise ValueError('Ring heights must strictly increase')
    if any(a[1] == b[1] == 0 for a, b in zip(p, p[1:])):
        raise ValueError('Adjacent zero-radius rings have no solid volume')
    return p


def profile_spans(profile):
    p = checked_profile(profile)
    return [p[i:i + 2] for i in range(len(p) - 1)]


def separate_materials(stem_seed, cap_seed):
    # Copy existing scene materials; do not infer paint/alloy from RGB values.
    stem = stem_seed.copy()
    cap = cap_seed.copy()
    stem.name = 'campus_lamp_stem_fit'
    cap.name = 'campus_lamp_cap_fit'
    return {'pole': stem, 'cap': cap}


def shape_lamp_part(root, child, base, axis, profile, role, material, segments=64):
    import bpy
    from mathutils import Vector

    tokens = {'pole': 'post', 'collar': 'collar', 'bowl': 'bowl',
              'rim': 'rim', 'cap': 'cap'}
    if role not in tokens or child.type != 'MESH' or material is None:
        raise ValueError('Unsupported exterior role, mesh or material')
    if not isinstance(segments, int) or segments < 16:
        raise ValueError('Insufficient radial tessellation')
    if child not in list(root.children_recursive):
        raise ValueError('Part must belong to the lamp root')
    if len(child.modifiers) or child.data.shape_keys is not None:
        raise ValueError('Bake modifiers/shape keys explicitly before replacing mesh')
    p = checked_profile(profile)
    base, axis = Vector(base), Vector(axis)
    if any(not math.isfinite(v) for v in list(base) + list(axis)) or axis.length == 0:
        raise ValueError('Invalid anchor or axis')
    axis.normalize()
    captured = root.get('captured_axis_blender')
    if captured is None:
        raise ValueError('Missing captured axis: do not invent upright alignment')
    captured = Vector(captured)
    if captured.length == 0 or axis.angle(captured.normalized()) > math.radians(0.1):
        raise ValueError('Requested axis disagrees with capture')
    # The caller passes the existing collision exporter's base and axis.
    # Never derive the ground anchor from a newly fitted bounding box.
    helper = Vector((1, 0, 0)) if abs(axis.x) < 0.9 else Vector((0, 1, 0))
    u = axis.cross(helper).normalized()
    v = axis.cross(u)
    inverse = child.matrix_world.inverted()
    vertices, rings, faces = [], [], []
    for height, radius in p:
        ring = []
        count = 1 if radius == 0 else segments
        for j in range(count):
            angle = 2 * math.pi * j / count
            world = base + height * axis + radius * (
                math.cos(angle) * u + math.sin(angle) * v)
            ring.append(len(vertices))
            vertices.append(tuple(inverse @ world))
        rings.append(ring)
    for a, b in zip(rings, rings[1:]):
        for j in range(segments):
            k = (j + 1) % segments
            if len(a) == 1:
                faces.append((a[0], b[k], b[j]))
            elif len(b) == 1:
                faces.append((a[j], a[k], b[0]))
            else:
                faces.append((a[j], a[k], b[k], b[j]))
    if len(rings[0]) > 1:
        faces.append(tuple(reversed(rings[0])))
    if len(rings[-1]) > 1:
        faces.append(tuple(rings[-1]))
    # Preserve outward winding even when a parent has a reflected transform.
    if child.matrix_world.to_3x3().determinant() < 0:
        faces = [tuple(reversed(face)) for face in faces]
    mesh = bpy.data.meshes.new(child.name + '_profile')
    mesh.from_pydata(vertices, [], faces)
    mesh.materials.append(material)
    mesh.update()
    child.data = mesh
    child.name = root.name + '_' + tokens[role]
    # Root/child matrices, captured axis and caller-owned anchor are unchanged.
    return child


def projected_sections(scene, camera, base, axis, heights):
    from bpy_extras.object_utils import world_to_camera_view
    from mathutils import Vector

    scale = scene.render.resolution_percentage / 100.0
    width = int(scene.render.resolution_x * scale)
    height = int(scene.render.resolution_y * scale)
    base, axis = Vector(base), Vector(axis).normalized()

    def project(point):
        q = world_to_camera_view(scene, camera, point)
        if q.z <= 0:
            raise ValueError('Section lies behind camera')
        return (q.x * width, (1 - q.y) * height)

    sections = {}
    for h in heights:
        h = float(h)
        a = project(base + h * axis)
        b = project(base + (h + 0.01) * axis)
        tangent = (b[0] - a[0], b[1] - a[1])
        if math.hypot(*tangent) < 1e-8:
            raise ValueError('Projected axis is unresolved')
        sections[h] = (a, tangent)
    return sections


def edge_width(mask, clear, center, tangent, half_window=32.0,
               step=0.25, min_width=4.0):
    # mask: target stem only, not the whole lamp or an RGB threshold.
    # clear: independently verified target/background visibility;
    #        occluders and unknown pixels are False.
    height = len(mask)
    if height == 0:
        raise ValueError('Empty mask')
    width = len(mask[0])
    if width == 0 or len(clear) != height:
        raise ValueError('Mask dimensions differ')
    if any(len(row) != width for row in mask) or any(len(row) != width for row in clear):
        raise ValueError('Ragged or mismatched masks')
    values = (*center, *tangent, half_window, step, min_width)
    if any(not math.isfinite(float(x)) for x in values):
        raise ValueError('Nonfinite sampling input')
    length = math.hypot(*tangent)
    if length == 0 or half_window <= 0 or step <= 0 or min_width <= 0:
        raise ValueError('Invalid sampling configuration')
    nx, ny = -tangent[1] / length, tangent[0] / length
    count = max(4, math.ceil(2 * half_window / step))
    ds = 2 * half_window / count
    hits = []
    for i in range(count + 1):
        t = -half_window + i * ds
        x = math.floor(center[0] + nx * t)
        y = math.floor(center[1] + ny * t)
        if not (0 <= x < width and 0 <= y < height):
            return None
        # Conservatively reject an entire section if any search pixel is unknown.
        if not bool(clear[y][x]):
            return None
        hits.append(bool(mask[y][x]))
    occupied = [i for i, value in enumerate(hits) if value]
    if not occupied:
        return None
    first, last = occupied[0], occupied[-1]
    if first < 2 or last > count - 2:
        return None  # window clips an edge or leaves no exterior guard
    if not hits[count // 2] or not all(hits[first:last + 1]):
        return None  # wrong axis, disconnected mask or an internal occlusion
    result = (last - first + 1) * ds
    return result if result >= min_width else None


def paired_widths(photo_mask, photo_clear, render_mask, render_clear,
                  photo_sections, render_sections, **sampling):
    accepted = []
    for h in sorted(set(photo_sections) & set(render_sections)):
        p = edge_width(photo_mask, photo_clear, *photo_sections[h], **sampling)
        r = edge_width(render_mask, render_clear, *render_sections[h], **sampling)
        if p is not None and r is not None:
            accepted.append((h, p, r))
    if not accepted:
        return None
    return {'photo_width_px': median(x[1] for x in accepted),
            'render_width_px': median(x[2] for x in accepted),
            'accepted_sections': accepted}
