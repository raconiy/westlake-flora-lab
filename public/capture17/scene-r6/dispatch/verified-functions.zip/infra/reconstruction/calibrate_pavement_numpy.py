import numpy as np

MAX_FLOAT = 1.7976931348623157e308
Y_WEIGHTS = np.array([0.2126, 0.7152, 0.0722])


def paving_gain(photo_y, render_y, confidence):
    return (1 + min(1, max(0, confidence)) *
            (min(1.8, max(0.45, photo_y / render_y)) - 1)) if (
        0 < photo_y <= MAX_FLOAT and
        0 < render_y <= MAX_FLOAT and
        abs(confidence) <= MAX_FLOAT) else 1


def srgb_to_linear(rgb):
    x = np.asarray(rgb, dtype=np.float64)
    if not np.isfinite(x).all() or np.any((x < 0) | (x > 1)):
        raise ValueError('Expected finite encoded sRGB in [0,1]')
    return np.where(x <= 0.04045, x / 12.92,
                    ((x + 0.055) / 1.055) ** 2.4)


def _blur(a, sigma):
    radius = int(np.ceil(3 * sigma))
    x = np.arange(-radius, radius + 1, dtype=np.float64)
    kernel = np.exp(-0.5 * (x / sigma) ** 2)
    kernel /= kernel.sum()
    out = a.astype(np.float64, copy=True)
    for axis in (0, 1):
        padding = [(0, 0), (0, 0)]
        padding[axis] = (radius, radius)
        out = np.apply_along_axis(
            lambda row: np.convolve(row, kernel, mode='valid'),
            axis, np.pad(out, padding, mode='constant'))
    return out


def _dilate(mask, radius):
    h, w = mask.shape
    padded = np.pad(mask, radius, mode='constant')
    out = np.zeros_like(mask)
    for dy in range(2 * radius + 1):
        for dx in range(2 * radius + 1):
            out |= padded[dy:dy + h, dx:dx + w]
    return out


def _shadow_check(photo_shadow, projected_shadow, pavement):
    a = photo_shadow & pavement
    b = projected_shadow & pavement
    if not (a.any() or b.any()):
        return {'status': 'unverified-no-shadow-evidence'}
    if min(int(a.sum()), int(b.sum())) < 32:
        raise ValueError('Insufficient or missing shadow evidence')
    iou = float((a & b).sum() / (a | b).sum())
    edge_a = a & _dilate(~a, 1)
    edge_b = b & _dilate(~b, 1)
    if not edge_a.any() or not edge_b.any():
        raise ValueError('No usable shadow boundary')
    cover_a = float(_dilate(edge_b, 2)[edge_a].mean())
    cover_b = float(_dilate(edge_a, 2)[edge_b].mean())
    if iou < 0.80 or min(cover_a, cover_b) < 0.95:
        raise ValueError('Reject wrong shadow projection; do not bake into albedo')
    return {'status': 'accepted', 'iou': iou,
            'boundary_coverage': min(cover_a, cover_b)}


def calibrate_pavement(photo_linear, render_linear,
                       photo_pavement, render_pavement,
                       grass_union, joints_union,
                       photo_specular, render_specular,
                       photo_shadow, projected_shadow,
                       confidence, sigma=12.0, min_support=256):
    p = np.asarray(photo_linear, dtype=np.float64)
    r = np.asarray(render_linear, dtype=np.float64)
    if p.ndim != 3 or p.shape[2] != 3 or p.shape != r.shape:
        raise ValueError('Expected registered HxWx3 RGB arrays')
    if not np.isfinite(sigma) or sigma <= 0:
        raise ValueError('sigma must be finite and positive')
    shape = p.shape[:2]

    def mask(value):
        value = np.asarray(value)
        if value.shape != shape or value.dtype != np.bool_:
            raise ValueError('Masks must be Boolean arrays matching RGB')
        return value

    pp, rp, grass, joints, ps, rs, sh_p, sh_r = map(mask, (
        photo_pavement, render_pavement, grass_union, joints_union,
        photo_specular, render_specular, photo_shadow, projected_shadow))
    pavement = pp & rp & ~grass
    shadow_report = _shadow_check(sh_p, sh_r, pavement)

    # Required specular masks must include unsaturated glints identified
    # independently. Brightness alone is not a reliable specular detector.
    finite = np.isfinite(p).all(axis=2) & np.isfinite(r).all(axis=2)
    nonnegative = (p >= 0).all(axis=2) & (r >= 0).all(axis=2)
    near_clip = (p >= 0.98).any(axis=2) | (r >= 0.98).any(axis=2)
    yp, yr = p @ Y_WEIGHTS, r @ Y_WEIGHTS
    excluded = grass | joints | ps | rs | sh_p | sh_r | near_clip
    common = (pavement & ~_dilate(excluded, 3) & finite & nonnegative &
              (yp > 1e-8) & (yr > 1e-8))
    weight = _blur(common.astype(np.float64), sigma)
    support = common & (weight >= 0.60)
    if int(support.sum()) < min_support:
        raise ValueError('Insufficient shared clean pavement support')

    def split(y):
        log_y = np.log(np.maximum(y, 1e-8))
        low = _blur(np.where(common, log_y, 0.0), sigma)
        low /= np.maximum(weight, 1e-12)
        center = float(np.median(low[support]))
        high = log_y - low
        incident = np.full(shape, np.nan)
        texture = np.full(shape, np.nan)
        incident[support] = np.exp(low[support] - center)
        texture[support] = np.exp(high[support])
        return np.exp(center), incident, texture, high

    bp, ip, tp, hp = split(yp)
    br, ir, tr, hr = split(yr)
    gain = paving_gain(float(bp), float(br), confidence)
    alpha = min(1, max(0, confidence)) if np.isfinite(confidence) else 0.0

    def mad(values):
        return float(np.median(np.abs(values - np.median(values))))

    spread_p, spread_r = mad(hp[support]), mad(hr[support])
    # Match robust texture contrast, not individual granite grains.
    target_contrast = (min(2.0, max(0.5, spread_p / spread_r))
                       if spread_r > 1e-6 else 1.0)
    contrast = 1 + alpha * (target_contrast - 1)
    corrected = r.copy()
    factor = gain * np.exp((contrast - 1) * hr[support])
    corrected[support] = r[support] * factor[:, None]
    # Keep HDR values: clipping here would hide calibration failures.
    return {'paving_gain': gain, 'texture_contrast': contrast,
            'base_y': (float(bp), float(br)),
            'incident': (ip, ir), 'texture': (tp, tr),
            'support': support, 'corrected_linear': corrected,
            'shadow_report': shadow_report}

