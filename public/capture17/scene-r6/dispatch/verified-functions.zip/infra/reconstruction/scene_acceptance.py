import numpy as np

SHAPE = (768, 1024)
CLASSES = ('foreground_tree', 'pole', 'usable_paving')

class EvidenceError(ValueError):
    pass

def need(ok, message):
    if not ok:
        raise EvidenceError(message)

def mask(value, label):
    need(isinstance(value, np.ndarray), label + ': 缺少 ndarray')
    need(value.shape == SHAPE and value.dtype == np.bool_,
         label + ': 必须是完整分辨率布尔分割')
    need(bool(value.any()), label + ': 空证据')
    return value

def number(value, label):
    need(not isinstance(value, (bool, np.bool_)), label + ': 不是数值')
    try:
        x = float(value)
    except (TypeError, ValueError):
        raise EvidenceError(label + ': 缺少有限数值') from None
    need(np.isfinite(x), label + ': 非有限数值')
    return x

def signed_support_clearance(record):
    return (number(record.get('lowest_world_m'), 'lowest_world_m')
            - number(record.get('ground_world_m'), 'ground_world_m'))

def camera(frame):
    c = frame.get('camera')
    need(isinstance(c, dict), '缺少相机证据')
    need((c.get('height'), c.get('width')) == SHAPE, '相机分辨率不匹配')
    need(c.get('projection') == 'pinhole_opencv'
         and c.get('world') == 'metres_Z_up', '不支持的相机/世界约定')
    try:
        k = np.asarray(c['K'], dtype=float)
        w = np.asarray(c['world_to_camera'], dtype=float)
    except (KeyError, TypeError, ValueError):
        raise EvidenceError('缺少有效相机矩阵') from None
    need(k.shape == (3, 3) and w.shape == (4, 4), '相机矩阵形状错误')
    need(np.isfinite(k).all() and np.isfinite(w).all(), '相机矩阵非有限')
    need(k[0, 0] > 0 and k[1, 1] > 0
         and abs(np.linalg.det(k)) > 1e-12
         and np.allclose(k[2], [0, 0, 1], atol=1e-10, rtol=0),
         '无效内参')
    r = w[:3, :3]
    need(np.allclose(w[3], [0, 0, 0, 1], atol=1e-10, rtol=0)
         and np.allclose(r.T @ r, np.eye(3), atol=1e-7, rtol=0)
         and abs(np.linalg.det(r) - 1) <= 1e-7, '外参不是刚体变换')
    return k, w

def adjacent(a, radius):
    p = np.pad(a, radius, constant_values=False)
    out = np.zeros_like(a)
    for dy in range(2 * radius + 1):
        for dx in range(2 * radius + 1):
            out |= p[dy:dy + SHAPE[0], dx:dx + SHAPE[1]]
    return out

def segment_metrics(a, b):
    # 调用前已拒绝空证据；每个类别单独保存分母，绝不合并计数。
    intersection = int(np.count_nonzero(a & b))
    union = int(np.count_nonzero(a | b))
    nr, npred = int(a.sum()), int(b.sum())
    return dict(ref_px=nr, pred_px=npred, union_px=union,
                intersection_px=intersection, iou=intersection / union,
                missed_fraction=(nr - intersection) / nr,
                extra_per_ref=(npred - intersection) / nr)

def validate_frame(frame, radius):
    need(isinstance(frame, dict), '缺少帧证据')
    silhouette = mask(frame.get('silhouette'), 'silhouette')
    classes = frame.get('classes')
    need(isinstance(classes, dict), '缺少类别分割')
    for name in CLASSES:
        m = mask(classes.get(name), name)
        need(not bool((m & ~silhouette).any()), name + ': 超出实体轮廓')
    supports = frame.get('supports')
    need(isinstance(supports, dict) and bool(supports), '缺少支撑清单')
    kinds = set()
    for sid, s in supports.items():
        need(isinstance(sid, str) and bool(sid) and isinstance(s, dict),
             '无效支撑记录')
        kind = s.get('kind')
        need(kind in ('foreground_tree', 'pole'), sid + ': 未知支撑类别')
        kinds.add(kind)
        foot = mask(s.get('foot'), sid + '/foot')
        ground = mask(s.get('local_ground'), sid + '/local_ground')
        contact = mask(s.get('contact'), sid + '/contact')
        need(not bool((foot & ~classes[kind]).any()), sid + ': 支撑不属于物体')
        need(not bool((ground & ~silhouette).any()), sid + ': 地面不属于场景')
        need(not bool((foot & ground).any()), sid + ': 支撑与可见地面标签重叠')
        need(not bool((contact & ~foot).any()), sid + ': 接触不属于支撑')
        need(not bool((contact & ~adjacent(ground, radius)).any()),
             sid + ': 接触分割没有邻接局部地面')
    need(kinds == {'foreground_tree', 'pole'}, '缺少树或杆接触证据')


def accept_scene(reference, variants, policy):
    need(isinstance(reference, dict), '缺少参考证据')
    need(isinstance(variants, dict) and set(variants) == {'bare', 'blades'},
         '必须同时提供 bare/blades 控制')
    need(isinstance(policy, dict), '缺少显式验收策略')
    unit_keys = ('silhouette_iou', 'class_iou', 'support_iou',
                 'contact_iou', 'control_support_iou', 'control_contact_iou')
    p = {k: number(policy.get(k), k) for k in unit_keys}
    need(all(0 <= x <= 1 for x in p.values()), 'IoU 阈值越界')
    for k in ('max_gap_m', 'max_penetration_m', 'control_clearance_m',
              'camera_atol'):
        p[k] = number(policy.get(k), k)
        need(p[k] >= 0, k + ': 阈值必须非负')
    radius = policy.get('contact_radius_px')
    need(type(radius) is int and 1 <= radius <= 8, '接触邻域必须为 1..8 像素')
    kr, wr = camera(reference)
    validate_frame(reference, radius)
    checks, reports, clearances = {}, {}, {}
    for mode in ('bare', 'blades'):
        frame = variants[mode]
        need(isinstance(frame, dict), mode + ': 缺少帧证据')
        k, w = camera(frame)
        need(np.allclose(k, kr, atol=p['camera_atol'], rtol=0)
             and np.allclose(w, wr, atol=p['camera_atol'], rtol=0),
             mode + ': 相机矩阵不兼容；禁止自动重配准')
        validate_frame(frame, radius)
        need(set(frame['supports']) == set(reference['supports']),
             mode + ': 支撑清单缺失或增加')
        report = {'classes': {}, 'supports': {}}
        report['silhouette'] = segment_metrics(reference['silhouette'],
                                                frame['silhouette'])
        checks[mode + '/silhouette'] = (
            report['silhouette']['iou'] >= p['silhouette_iou'])
        for name in CLASSES:
            stats = segment_metrics(reference['classes'][name],
                                    frame['classes'][name])
            report['classes'][name] = stats
            checks[mode + '/' + name] = stats['iou'] >= p['class_iou']
        clearances[mode] = {}
        for sid, rs in reference['supports'].items():
            s = frame['supports'][sid]
            need(s['kind'] == rs['kind'], sid + ': 类别改变')
            foot = segment_metrics(rs['foot'], s['foot'])
            contact = segment_metrics(rs['contact'], s['contact'])
            d = signed_support_clearance(s)
            clearances[mode][sid] = d
            report['supports'][sid] = dict(foot=foot, contact=contact,
                                           signed_support_clearance=d)
            checks[mode + '/' + sid + '/support'] = foot['iou'] >= p['support_iou']
            checks[mode + '/' + sid + '/contact'] = contact['iou'] >= p['contact_iou']
            checks[mode + '/' + sid + '/world_contact'] = (
                -p['max_penetration_m'] <= d <= p['max_gap_m'])
        reports[mode] = report
    for sid in reference['supports']:
        a, b = (variants[m]['supports'][sid] for m in ('bare', 'blades'))
        checks['control/' + sid + '/foot'] = (
            segment_metrics(a['foot'], b['foot'])['iou'] >= p['control_support_iou'])
        checks['control/' + sid + '/contact'] = (
            segment_metrics(a['contact'], b['contact'])['iou'] >= p['control_contact_iou'])
        checks['control/' + sid + '/clearance'] = (
            abs(clearances['bare'][sid] - clearances['blades'][sid])
            <= p['control_clearance_m'])
    return dict(accepted=all(checks.values()), checks=checks, reports=reports)
