import numpy as np
import pytest
from infra.reconstruction.calibrate_pavement_numpy import (
    calibrate_pavement, paving_gain)


def test_scalar():
    assert paving_gain(0.2, 0.5, 1) == pytest.approx(0.45)
    assert paving_gain(0.2, 0.5, 0.5) == pytest.approx(0.725)
    assert paving_gain(2.0, 0.5, 1) == pytest.approx(1.8)
    assert paving_gain(0.2, 0.5, -1) == 1
    for p, r, c in [(0, 1, 1), (-1, -1, 1), (1, 0, 1),
                    (np.nan, 1, 1), (1, np.inf, 1),
                    (1, 1, np.nan), (1, 1, np.inf)]:
        assert paving_gain(p, r, c) == 1


def fixture():
    yy, xx = np.mgrid[:96, :128]
    y = 0.35 * np.exp(0.10 * xx / 128 + 0.03 * np.sin(xx * 2))
    r = np.repeat(y[..., None], 3, axis=2)
    p = 0.6 * r
    grass = yy < 16
    pavement = ~grass
    joints = xx == 64
    spec = (yy >= 20) & (yy < 24) & (xx >= 20) & (xx < 24)
    shadow = (yy >= 40) & (yy < 64) & (xx >= 30) & (xx < 58)
    return p, r, pavement, grass, joints, spec, shadow


def call(p, r, pavement, grass, joints, spec, shadow, projected=None):
    return calibrate_pavement(
        p, r, pavement, pavement, grass, joints, spec, spec,
        shadow, shadow if projected is None else projected,
        confidence=1.0, sigma=4.0)


def test_split_gain_and_protected_pixels():
    p, r, pavement, grass, joints, spec, shadow = fixture()
    original = r.copy()
    out = call(p, r, pavement, grass, joints, spec, shadow)
    support = out['support']
    assert out['paving_gain'] == pytest.approx(0.6)
    assert out['texture_contrast'] == pytest.approx(1.0)
    assert not np.any(support & (grass | joints | spec | shadow))
    np.testing.assert_array_equal(r, original)
    np.testing.assert_array_equal(out['corrected_linear'][~support], r[~support])
    np.testing.assert_allclose(out['corrected_linear'][support], p[support])
    for index, rgb in enumerate((p, r)):
        reconstructed = (out['base_y'][index] * out['incident'][index] *
                         out['texture'][index])
        expected = rgb @ np.array([0.2126, 0.7152, 0.0722])
        np.testing.assert_allclose(reconstructed[support], expected[support])


def test_explicit_wrong_projection_failure():
    p, r, pavement, grass, joints, spec, shadow = fixture()
    wrong = np.roll(shadow, 10, axis=1)
    with pytest.raises(ValueError, match='wrong shadow projection'):
        call(p, r, pavement, grass, joints, spec, shadow, wrong)


def test_missing_shared_support_failure():
    p, r, pavement, grass, joints, spec, shadow = fixture()
    with pytest.raises(ValueError, match='Insufficient shared'):
        call(p, r, pavement, grass, np.ones_like(joints), spec, shadow)

