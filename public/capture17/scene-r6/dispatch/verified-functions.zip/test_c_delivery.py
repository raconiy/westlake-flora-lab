"""Run C-round assertions against their exact recorded evidence and explicit synthetic controls."""
from pathlib import Path
import json
import copy
import pytest
from test_c_articulation import accept_articulation
from test_c_contact import check_right_tree
from test_c_fixtures import assert_optic_nonregression
from test_c_pavement import assert_withheld_positions
from test_c_crown import assert_hard_gaps

def evidence(role):
    return json.loads((Path(__file__).parent/'c-inputs'/(role+'.json')).read_text())

def test_final_fixture_nonregression_claim_is_rejected():
    with pytest.raises(AssertionError):
        assert_optic_nonregression(evidence('fixtures'))

def test_incomplete_seam_position_claim_is_rejected():
    with pytest.raises(AssertionError):
        assert_withheld_positions(evidence('pavement'))

def test_contact_policy_examples_are_distinct():
    p=evidence('contact')
    with pytest.raises(AssertionError):
        check_right_tree(p,(-.005,.005),60)
    assert check_right_tree(p,(-.13,.005),60)['right_tree_proxy_and_selected_projection_checks']
    stale=copy.deepcopy(p)
    stale['release']['xmlSHA256']='0'*64
    with pytest.raises(AssertionError):
        check_right_tree(stale,(-.13,.005),60)

def test_actual_final_motion_accepts_declared_extensions():
    p=evidence('articulation')
    n=evidence('joint-names')
    declared=p['evidence']['identity']['addedJointNames']
    assert accept_articulation(p['evidence'],p['release'],n['old'],n['new'],declared,1e-6)
    with pytest.raises(AssertionError):
        accept_articulation(p['evidence'],p['release'],n['old'],n['new'][1:],declared,1e-6)

def test_hard_sky_masks_with_synthetic_leaf_control():
    v={k:dict(reviewed=True,full_potential_cover=True,known=[True,False],
              holes=[True,False],leaf_cover=[[True,False],[False,True]],
              valid=[True,True]) for k in ['01','03','06','09']}
    with pytest.raises(AssertionError):
        assert_hard_gaps(v,[True,True])
    assert_hard_gaps(v,[False,True])
