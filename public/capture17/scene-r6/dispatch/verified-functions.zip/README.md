# 云谷实拍全场景 R6 · 已执行的模型交付
从各账号真实答复提取的确定性函数与测试。A 轮的 NumPy / Python 模块位于 infra/reconstruction，B 轮带内嵌断言的函数与模型给的示例位于 test_b_*.py。依赖 Python 3.9 及以上、NumPy 与 pytest。每个函数的实际采用范围见同页 records.json 的 disposition。

在解压目录内运行 A 轮测试

    python -m pytest -q test_contact.py test_crown.py test_fixtures.py test_pavement.py

运行 B 轮完整代码示例

    python test_b_articulation.py
    python test_b_contact.py
    python test_b_crown.py
    python test_b_fixtures.py
    python test_b_pavement.py

运动实物复核使用场景仓库内的 Three.js 和正式的 lib/capture-wind.ts。先在场景项目安装其锁定依赖，取对应版本的 GLB，在 Node.js 支持原生读取 TypeScript 的版本运行

    node --experimental-strip-types evaluate-motion.mjs /path/to/scene-repository /path/to/yungu-lawn.glb motion.json

C 轮逐岗裁决的原始 Python 断言位于 test_c_*.py，c-inputs 包含其实际收取的数值证据与图片摘要。运行下述命令时，灯罩和缝位的拒绝是预期结果，冠层案例为显式合成叶掩膜。

    python -m pytest -q test_c_delivery.py

两个版本的具名枝条可运行一次局部四元数、插槽和已绑叶网格验收

    node --experimental-strip-types compare-mobility.mjs /path/to/scene-repository /path/to/old.glb /path/to/new.glb named-motion.json

以下命令用项目附带的 meshopt 解码实际路径灯的世界空间三角形

    node extract-lamp.mjs /path/to/scene-repository /path/to/yungu-lawn.glb lamp-mesh.json

B 轮运动例程的65个风关节与13个固定锚是本场景单变量试验的签名。以后增添资产时应验证原有接口及新增资产，再制定对应阈值。测试中的合成截面、遮挡和故障注入属于回归样例。树冠示例的硬孔洞约束是工程实现的候选策略，文件本身不证明真实树冠的每个空隙都受到保护。
