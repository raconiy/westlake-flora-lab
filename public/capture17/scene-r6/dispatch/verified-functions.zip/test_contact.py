import copy
import unittest
import numpy as np
from infra.reconstruction.scene_acceptance import (
    SHAPE, EvidenceError, accept_scene, signed_support_clearance)


def rectangle(y0, y1, x0, x1):
    a = np.zeros(SHAPE, dtype=bool)
    a[y0:y1, x0:x1] = True
    return a


def fixture():
    frame = {
        'camera': {'height': 768, 'width': 1024,
                   'projection': 'pinhole_opencv', 'world': 'metres_Z_up',
                   'K': [[800, 0, 512], [0, 800, 384], [0, 0, 1]],
                   'world_to_camera': np.eye(4)},
        'silhouette': rectangle(90, 750, 0, 1024),
        'classes': {'foreground_tree': rectangle(100, 501, 100, 120),
                    'pole': rectangle(100, 501, 300, 305),
                    'usable_paving': rectangle(600, 700, 0, 1024)},
        'supports': {}}
    for sid, kind, x0, x1 in (
            ('tree-A', 'foreground_tree', 100, 120),
            ('pole-A', 'pole', 300, 305)):
        frame['supports'][sid] = {
            'kind': kind, 'foot': rectangle(495, 501, x0, x1),
            'local_ground': rectangle(501, 510, x0 - 2, x1 + 2),
            'contact': rectangle(500, 501, x0, x1),
            'lowest_world_m': 0.0, 'ground_world_m': 0.0}
    policy = {k: 0.9 for k in (
        'silhouette_iou', 'class_iou', 'support_iou', 'contact_iou',
        'control_support_iou', 'control_contact_iou')}
    policy.update(max_gap_m=0.005, max_penetration_m=0.005,
                  control_clearance_m=0.001, camera_atol=1e-8,
                  contact_radius_px=1)
    return frame, {m: copy.deepcopy(frame) for m in ('bare', 'blades')}, policy


class AcceptanceTests(unittest.TestCase):
    def test_bare_blades_control_and_sign(self):
        r, v, p = fixture()
        self.assertTrue(accept_scene(r, v, p)['accepted'])
        self.assertAlmostEqual(signed_support_clearance(
            {'lowest_world_m': 1.02, 'ground_world_m': 1}), 0.02)
        self.assertAlmostEqual(signed_support_clearance(
            {'lowest_world_m': 0.98, 'ground_world_m': 1}), -0.02)

    def test_gap_and_penetration_fail_despite_matching_pixels(self):
        for d in (0.03, -0.03):
            r, v, p = fixture()
            for mode in v:
                v[mode]['supports']['tree-A']['lowest_world_m'] = d
            result = accept_scene(r, v, p)
            self.assertFalse(result['accepted'])
            self.assertFalse(result['checks']['bare/tree-A/world_contact'])

    def test_missing_or_blades_hidden_contact_is_invalid(self):
        for empty in (False, True):
            r, v, p = fixture()
            s = v['blades']['supports']['tree-A']
            if empty:
                s['contact'][:] = False
            else:
                del s['contact']
            with self.assertRaises(EvidenceError):
                accept_scene(r, v, p)

    def test_incompatible_camera_is_invalid(self):
        r, v, p = fixture()
        v['blades']['camera']['world_to_camera'][0, 3] = 0.1
        with self.assertRaises(EvidenceError):
            accept_scene(r, v, p)

    def test_missing_support_and_empty_pole_are_invalid(self):
        for missing in (False, True):
            r, v, p = fixture()
            if missing:
                del v['bare']['supports']['pole-A']
            else:
                v['bare']['classes']['pole'][:] = False
            with self.assertRaises(EvidenceError):
                accept_scene(r, v, p)

    def test_separate_denominators_prevent_paving_dominance(self):
        r, v, p = fixture()
        v['bare']['classes']['foreground_tree'][:490] = False
        result = accept_scene(r, v, p)
        self.assertFalse(result['accepted'])
        stats = result['reports']['bare']['classes']
        self.assertEqual(stats['foreground_tree']['ref_px'], 401 * 20)
        self.assertEqual(stats['pole']['ref_px'], 401 * 5)
        self.assertEqual(stats['usable_paving']['ref_px'], 100 * 1024)
        self.assertEqual(stats['usable_paving']['iou'], 1.0)
        self.assertFalse(result['checks']['bare/foreground_tree'])

    def test_full_scene_failure_not_hidden_by_good_supports(self):
        r, v, p = fixture()
        v['bare']['silhouette'][:, 500:] = False
        v['bare']['classes']['usable_paving'][:, 500:] = False
        result = accept_scene(r, v, p)
        self.assertFalse(result['accepted'])
        self.assertFalse(result['checks']['bare/silhouette'])
        self.assertTrue(result['checks']['bare/tree-A/contact'])


if __name__ == '__main__':
    unittest.main()
