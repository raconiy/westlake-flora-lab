from math import isfinite

def accept_articulation(e, release, old_names, new_names,
                        declared_new, inversion_tol_rad):
    def nonnegative(x):
        return isinstance(x, (int, float)) and isfinite(x) and x >= 0

    assert nonnegative(inversion_tol_rad)
    old_names, new_names, declared_new = map(
        tuple, (old_names, new_names, declared_new))
    O, N, D = map(set, (old_names, new_names, declared_new))
    assert all(isinstance(n, str) and n for n in O | N | D)
    assert len(O) == len(old_names) > 0
    assert len(N) == len(new_names)
    assert len(D) == len(declared_new)
    assert O <= N, 'lost original joint names'
    assert D == N - O, 'undeclared or absent new names'

    i = e['identity']
    b, c = i['baseline'], i['candidate']
    assert b['sha256'] == e['old']['glbSha256']
    assert c['sha256'] == e['merged']['glbSha256'] == release['assetSHA256']
    assert b['joints'] == len(O) and c['joints'] == len(N)
    assert i['sharedJointCount'] == len(O & N)
    added, removed = i['addedJointNames'], i['removedJointNames']
    assert len(added) == len(set(added)) and set(added) == D
    assert removed == []
    anchors = set(b['anchorNames'])
    assert anchors and len(anchors) == len(b['anchorNames'])
    assert set(c['anchorNames']) == anchors
    assert len(c['anchorNames']) == len(anchors)
    for state in (b, c):
        for key in ('maxBaseMatrixDrift', 'maxLocalSocketDriftM',
                    'maxReleaseAngleRad'):
            assert state[key] == 0, key
        err = state['maxSignedInversionErrorRad']
        assert nonnegative(err) and err <= inversion_tol_rad
        assert state['leafMeshes'] == state['attachedLeafMeshes'] > 0

    for key, names in (('old', O), ('merged', N)):
        rows = e[key]['results']
        assert len(rows) == 3 and {r['hz'] for r in rows} == {30, 60, 120}
        for r in rows:
            err = r['maxSignedRotationInversionErrorRad']
            assert nonnegative(err) and err <= inversion_tol_rad
            for direction, sign in (('positive', 1), ('negative', -1)):
                q = r[direction]
                assert q['hz'] == r['hz'] and q['sign'] == sign
                assert q['joints'] == len(names) and q['bases'] == len(anchors)
                for field in ('peakTipCm', 'loadedTipCm', 'settledTipCm',
                              'maxFixedMatrixDelta', 'maxJointLocalSocketMotionM'):
                    assert nonnegative(q[field]), field
                assert 0 < q['loadedTipCm'] <= q['peakTipCm'], 'no loaded response'
                assert q['settledTipCm'] == 0, 'unloaded calm failed'
                assert q['maxFixedMatrixDelta'] == 0, 'moving root'
                assert q['maxJointLocalSocketMotionM'] == 0, 'moving socket'
    return True

