def paired_width_delta(photo, old, new, visible, centre, tangent, oid=1):
    import numpy as np
    photo, old, new, vo, vn = [np.asarray(a) for a in (photo, old, new, *visible)]
    arrays = (photo, old, new, vo, vn)
    if any(a.ndim != 2 or a.shape != photo.shape or a.dtype.kind not in 'iu' for a in arrays):
        raise ValueError('integer_registered_labels_required')
    if oid <= 0 or not np.isin(photo, [0, 1, 2, 3, 4]).all(): raise ValueError('labels')
    c, t = np.asarray(centre, float), np.asarray(tangent, float)
    if c.shape != (2,) or t.shape != (2,) or not np.isfinite([c, t]).all(): raise ValueError('coordinates')
    length = np.linalg.norm(t)
    if length < 1: raise ValueError('projected_axis')
    t = t / length; normal = np.array([-t[1], t[0]])
    s = np.arange(-16., 16.001, .25); ray = c + s[:, None] * normal
    band = np.stack((ray - t, ray, ray + t))
    def sample(a, points):
        a = np.asarray(a, float); x, y = points[..., 0], points[..., 1]
        if ((x < 0) | (y < 0) | (x >= a.shape[1]-1) | (y >= a.shape[0]-1)).any():
            raise ValueError('image_boundary')
        ix, iy = np.floor(x).astype(int), np.floor(y).astype(int)
        u, v = x - ix, y - iy
        return ((1-u)*(1-v)*a[iy, ix] + u*(1-v)*a[iy, ix+1]
                + (1-u)*v*a[iy+1, ix] + u*v*a[iy+1, ix+1])
    for code, reason in ((2, 'filled_shadow'), (3, 'missing_segment'), (4, 'photo_occlusion')):
        if (sample(photo == code, band) > 0).any(): raise ValueError(reason)
    for isolated, seen in ((old, vo), (new, vn)):
        if (sample((isolated == oid) != (seen == oid), band) > 0).any(): raise ValueError('render_occlusion')
    widths, positions = [], []
    for mask in (photo == 1, old == oid, new == oid):
        values = sample(mask, ray)
        k = np.flatnonzero((values[:-1] >= .5) != (values[1:] >= .5))
        if len(k) != 2 or values[0] >= .5 or values[-1] >= .5 or sample(mask, c[None])[0] < .5:
            raise ValueError('clipped_split_or_missing_edges')
        edges = s[k] + .25 * (.5-values[k]) / (values[k+1]-values[k])
        points = c + edges[:, None] * normal
        gx = sample(mask, points + [.5, 0]) - sample(mask, points - [.5, 0])
        gy = sample(mask, points + [0, .5]) - sample(mask, points - [0, .5])
        gradient = np.stack((gx, gy), axis=1); strength = np.linalg.norm(gradient, axis=1)
        if (strength < .25).any() or (abs(gradient @ normal) < .7 * strength).any():
            raise ValueError('ill_conditioned_edges')
        widths.append(float(edges[1]-edges[0])); positions.append(points.tolist())
    p, o, n = widths
    return {'photo': p, 'old': o, 'new': n, 'delta': abs(o-p)-abs(n-p), 'edges_xy': positions}

if __name__ == '__main__':
    import numpy as np
    p = np.zeros((32, 48), np.uint8); p[:, 21:28] = 1
    o = np.zeros_like(p); o[:, 19:29] = 1
    n = np.zeros_like(p); n[:, 20:28] = 1
    result = paired_width_delta(p, o, n, (o, n), (24, 16), (0, 4))
    assert np.allclose([result[k] for k in ('photo', 'old', 'new', 'delta')], [7, 10, 8, 2])
    shadow = p.copy(); shadow[:, 24] = 2
    missing = p.copy(); missing[:, 24] = 3
    occluded = o.copy(); occluded[:, 19] = 0
    for target, vis, axis, reason in ((shadow, (o,n), (0,4), 'filled_shadow'), (missing, (o,n), (0,4), 'missing_segment'), (p, (occluded,n), (0,4), 'render_occlusion'), (p, (o,n), (0,0), 'projected_axis')):
        try: paired_width_delta(target, o, n, vis, (24,16), axis)
        except ValueError as exc: assert str(exc) == reason
        else: raise AssertionError(reason)
