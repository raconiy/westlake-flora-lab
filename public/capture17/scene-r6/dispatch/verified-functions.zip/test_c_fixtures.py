def assert_optic_nonregression(payload):
    cases = payload['evidence']['fullSceneOptic']['cases']
    for camera in ('01', '13'):
        m = cases[camera]['measurements']
        old = m['R5']['meanAbsLinearRGBVersusPhoto']
        new = m['R6']['meanAbsLinearRGBVersusPhoto']
        assert 0 <= new <= old < float('inf'), (camera, new - old)
