import numpy as np


def register_scene(d):
    out = {'accepted': False, 'reasons': [], 'common_px': None, 'objects': None}
    def bad(s):
        out['reasons'].append(s)
    def vec(x):
        if not np.all(np.isfinite(x)): raise ValueError()
        return np.round(x, 6).tolist()
    def row(x, size):
        if x is None: return None
        a = np.asarray(x, dtype=float)
        if a.shape != (size,) or not np.all(np.isfinite(a)): raise ValueError()
        if not 0 <= a[4] <= 1 or a[5] not in (0, 1): raise ValueError()
        return None if a[5] or a[4] == 0 else (a[2:4]-a[:2], a[4], a[6:].reshape(2, 2) if size == 10 else None)
    def fit(A, b, w):
        x = np.zeros(2)
        for _ in range(5):
            h = np.minimum(1., 2./np.maximum(np.linalg.norm(A@x-b, axis=1), 1e-12))
            q = np.sqrt(w*h)[:, None, None]
            M = (A*q).reshape(-1, 2); y = (b*q[:, :, 0]).reshape(-1)
            s = np.linalg.svd(M, compute_uv=False)
            if len(s) < 2 or s[0] <= 0 or s[-1] <= s[0]*1e-6: raise ArithmeticError()
            x = np.linalg.lstsq(M, y, rcond=None)[0]
        return x
    try:
        views = d['views']; fixed = d['fixed']; lamp = d['lamp_id']
        if len(views) < 2 or len(set(views)) != len(views) or lamp not in fixed: raise ValueError()
        if not all(isinstance(v, str) for v in views): raise ValueError()
        ground = float(d['ground_z_m'])
        if not np.isfinite(ground) or not d['objects'] or set(d['objects']) & set(fixed): raise ValueError()
        common = {}
        for v in views:
            rows = {k: row(a.get(v), 6) for k, a in fixed.items()}
            good = [a for a in rows.values() if a is not None]
            if rows[lamp] is None or len(good) < 3:
                bad(v+':missing_fixed_support'); continue
            r = np.array([a[0] for a in good]); w = np.array([a[1] for a in good])
            c = []
            for j in range(2):
                ix = np.argsort(r[:, j], kind='stable')
                c.append(r[ix[np.searchsorted(np.cumsum(w[ix]), w.sum()/2)], j])
            common[v] = np.array(c)
            if np.linalg.norm(rows[lamp][0]-common[v]) > 1.: bad(v+':lamp_disagreement')
        if out['reasons']: return out
        out['common_px'] = {v: vec(common[v]) for v in views}; out['objects'] = {}
        for root, o in d['objects'].items():
            start = len(out['reasons']); rr = [row(o.get('root', {}).get(v), 10) for v in views]
            den = float(o.get('support_denominator', 0)); sw = sum(r[1] for r in rr if r is not None)
            if not np.isfinite(den) or den <= 0 or sw > den+1e-9 or sw < .6*den: bad(root+':support_denominator')
            if any(r is None for r in rr): bad(root+':missing_view')
            p = np.asarray(o.get('support', []), dtype=float)
            if p.shape != (3,) or not np.all(np.isfinite(p)): bad(root+':missing_support')
            if len(out['reasons']) > start: continue
            A = np.array([r[2] for r in rr]); b = np.array([r[0]-common[v] for r, v in zip(rr, views)])
            w = np.array([r[1] for r in rr])
            try: x = fit(A, b, w)
            except ArithmeticError:
                bad(root+':rank_deficient'); continue
            loo = []
            try:
                for i in range(len(views)):
                    use = np.arange(len(views)) != i
                    t = fit(A[use], b[use], w[use])
                    loo.append(float(np.linalg.norm(A[i]@t-b[i])))
            except ArithmeticError:
                bad(root+':loo_rank_deficient'); continue
            before = float(np.sqrt(np.sum(w*np.sum(b*b, axis=1))/sw))
            e = A@x-b; after = float(np.sqrt(np.sum(w*np.sum(e*e, axis=1))/sw))
            if not np.all(np.isfinite([before, after, *loo])): raise ValueError()
            if after > 1. or after > before+1e-9: bad(root+':residual_error')
            if max(loo) > 1.: bad(root+':loo_error')
            if np.linalg.norm(x) > .25: bad(root+':step_limit')
            if p[2]-ground < -.005: bad(root+':penetration')
            crown = {}
            for v in views:
                r = row(o.get('crown', {}).get(v), 10)
                crown[v] = None if r is None else vec(r[0]-common[v]-r[2]@x)
            out['objects'][root] = {'delta_blender_m': vec([x[0], x[1], 0]), 'root_rmse_px': round(before, 6),
                'corrected_rmse_px': round(after, 6), 'loo_max_px': round(max(loo), 6), 'crown_residual_px': crown}
        out['accepted'] = not out['reasons']
        return out
    except (KeyError, TypeError, ValueError, AttributeError, OverflowError, np.linalg.LinAlgError):
        return {'accepted': False, 'reasons': ['invalid_input'], 'common_px': None, 'objects': None}
