import numpy as np


def separate_bark(payload):
    """Relative appearance correction; angular illumination, tapered application."""
    def fail(reason):
        return {'ok': False, 'reason': reason}
    if not isinstance(payload, dict) or any(k not in payload for k in
            ('linearRGB', 'confidence', 'illuminationBounds')):
        return fail('missing_evidence')
    try:
        rgb = np.asarray(payload['linearRGB'], float)
        c = np.asarray(payload['confidence'], float).copy()
        bounds = np.asarray(payload['illuminationBounds'], float)
    except (TypeError, ValueError, OverflowError):
        return fail('invalid_input')
    if rgb.ndim != 3 or rgb.shape[-1] != 3:
        return fail('invalid_input')
    h, w, _ = rgb.shape
    if h < 1 or w < 4 or c.shape != (h, w) or bounds.shape != (2,):
        return fail('invalid_input')
    if not all(np.isfinite(a).all() for a in (rgb, c, bounds)):
        return fail('invalid_input')
    lo, hi = bounds
    if not (0 < lo <= 1 <= hi) or np.any((rgb < 0) | (rgb > 1)):
        return fail('invalid_input')
    if np.any((c < 0) | (c > 1)):
        return fail('invalid_input')
    if not np.array_equal(rgb[:, 0], rgb[:, -1]):
        return fail('seam_mismatch')
    c[:, 0] = c[:, -1] = np.minimum(c[:, 0], c[:, -1])
    lum = rgb @ np.array([.2126, .7152, .0722])
    peak = rgb.max(axis=2)
    if np.any((c > 0) & (peak >= .995)):
        return fail('supported_highlight')
    ratio = rgb.min(axis=2) / np.maximum(peak, 1e-12)
    good = (lum > 1e-4) & (peak < .995) & (ratio >= .02)
    weights = c * good
    weights[:, [0, -1]] *= .5
    if np.count_nonzero(weights.sum(axis=0)) < 3:
        return fail('insufficient_evidence')
    theta = np.linspace(0, 2*np.pi, w)
    x = np.column_stack((np.ones(w), np.cos(theta), np.sin(theta)))
    x[-1] = x[0]
    a = np.broadcast_to(x, (h, w, 3)).reshape(-1, 3)
    keep = weights.ravel() > 0
    a, y = a[keep], np.log(np.maximum(lum, 1e-4)).ravel()[keep]
    base = weights.ravel()[keep]
    rw = base.copy()
    try:
        for _ in range(8):
            root = np.sqrt(rw)
            aw = a * root[:, None]
            if np.linalg.matrix_rank(aw) < 3 or np.linalg.cond(aw) > 100:
                return fail('insufficient_angular_support')
            beta = np.linalg.lstsq(aw, y*root, rcond=None)[0]
            rw = base * np.minimum(1., .2/np.maximum(np.abs(y-a@beta), 1e-12))
    except np.linalg.LinAlgError:
        return fail('insufficient_angular_support')
    raw = x[:, 1:] @ beta[1:]
    amp = float(np.linalg.norm(beta[1:]))
    scale = min(1., -np.log(lo)/amp, np.log(hi)/amp) if amp > 0 else 1.
    limited = (raw < np.log(lo)-1e-9) | (raw > np.log(hi)+1e-9)
    q = raw * scale
    def smooth(z):
        z = np.clip(z, 0., 1.)
        return z*z*(3.-2.*z)
    gate = smooth((lum-1e-4)/1e-4) * smooth((.995-peak)/.015)
    gate *= smooth((ratio-.02)/.02)
    taper = smooth(c) * gate
    d = taper * q[None, :]
    brightening = d < 0
    cap = float(np.min(np.log(peak[brightening])/d[brightening])) if brightening.any() else 1.
    strength = min(1., cap)
    safety = 1.-1e-12 if strength < 1. else 1.
    strength *= safety
    field = np.exp(strength*q)
    divisor = np.exp(strength*d)
    out = rgb.copy()
    apply = taper > 0
    out[apply] = rgb[apply] / divisor[apply, None]
    if not np.isfinite(out).all() or np.any((out < 0) | (out > 1)):
        return fail('numeric_range')
    if not np.isfinite(field).all() or np.any((field < lo) | (field > hi)):
        return fail('numeric_bounds')
    support = c * gate * strength * scale * (~limited)[None, :]
    diagnostics = {'strength': float(strength), 'rangeCap': cap,
                   'boundScale': float(scale), 'safetyFactor': safety,
                   'conservative': bool(strength < 1.-1e-12 or scale < 1.-1e-12),
                   'unmodifiedPixels': int((~apply).sum()),
                   'illuminationMeaning': 'angular reference; effective divisor exp(taper*log(field))'}
    return {'ok': True, 'linearRGB': out.tolist(), 'illumination': field.tolist(),
            'confidence': support.tolist(), 'limited': limited.tolist(),
            'diagnostics': diagnostics}
