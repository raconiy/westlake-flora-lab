import numpy as np


def triangle_sky_guard(data):
    """Same-unit coverage delta; closed edges, centres (x+.5,y+.5)."""
    try:
        sky = np.asarray(data['sky'])
        units = data['unit_ids']; n = len(units)
        if not isinstance(units, list) or not n: raise ValueError()
        if any(not isinstance(u, str) or not u for u in units): raise ValueError()
        if sky.ndim != 2 or not sky.size or sky.dtype.kind not in 'biu': raise ValueError()
        if not np.all((sky == 0) | (sky == 1)): raise ValueError()
        h, w = sky.shape
        old = np.asarray(data['old_triangles'], dtype=float)
        new = np.asarray(data['new_triangles'], dtype=float)
        ov = np.asarray(data.get('old_valid', [False]*n))
        nv = np.asarray(data.get('new_valid', [False]*n))
        if old.shape != (n, 3, 2) or new.shape != old.shape: raise ValueError()
        if ov.shape != (n,) or nv.shape != (n,): raise ValueError()
        if ov.dtype.kind != 'b' or nv.dtype.kind != 'b': raise ValueError()
        bad = ~(ov & nv)
        for t in (old, new):
            bad |= ~np.isfinite(t).all(axis=(1, 2))
            bad |= (t < 0).any(axis=(1, 2)) | (t > [w, h]).any(axis=(1, 2))
        groups = {}
        for i, u in enumerate(units): groups.setdefault(u, []).append(i)
        rows = []
        for u in sorted(groups):
            idx = groups[u]; missing = bool(bad[idx].any()); pixels = None
            if not missing:
                coverage = []
                for triangles in (old[idx], new[idx]):
                    parts = [np.empty(0, dtype=np.int64)]
                    for t in triangles:
                        a, b = t[1]-t[0], t[2]-t[0]
                        area = a[0]*b[1]-a[1]*b[0]
                        if area == 0: continue
                        lo = np.maximum(0, np.ceil(t.min(axis=0)-.5)).astype(int)
                        hi = np.minimum([w-1, h-1], np.floor(t.max(axis=0)-.5)).astype(int)
                        xx, yy = np.meshgrid(np.arange(lo[0], hi[0]+1),
                                             np.arange(lo[1], hi[1]+1))
                        hit = np.ones(xx.shape, dtype=bool)
                        for p, q in zip(t, np.roll(t, -1, axis=0)):
                            edge = (q[0]-p[0])*(yy+.5-p[1])-(q[1]-p[1])*(xx+.5-p[0])
                            hit &= (edge >= 0) if area > 0 else (edge <= 0)
                        parts.append(yy[hit]*w+xx[hit])
                    coverage.append(np.unique(np.concatenate(parts)))
                delta = np.setdiff1d(coverage[1], coverage[0], assume_unique=True)
                delta = delta[sky.ravel()[delta].astype(bool)]
                pixels = np.column_stack((delta % w, delta // w)).tolist()
            rows.append({'unit': u, 'new_sky_pixels': pixels,
                         'new_sky_count': None if missing else len(pixels),
                         'veto': missing or bool(pixels), 'missing_evidence': missing})
        return {'ok': True, 'units': rows}
    except (KeyError, TypeError, ValueError, OverflowError, AttributeError):
        return {'ok': False, 'veto_all': True, 'error': 'missing_or_invalid_input'}
