import numpy as np


def audit_turf(data):
    """Exact non-regression gate; texture order: gradient error, luma error."""
    if not isinstance(data, dict):
        return {'error': 'unknown:input', 'regions': []}
    src = data.get('controls', {})
    src = src if isinstance(src, dict) else {}
    controls = {}
    for name, key in [('bare', 'bareMaxDelta'), ('release', 'releasedMaxDelta')]:
        v = src.get(key)
        valid = type(v) in (int, float) and np.isfinite(v) and 0 <= v <= 1
        controls[name] = ('pass' if v == 0 else 'fail') if valid else 'unknown'
    v = src.get('cameraConsistent')
    controls['camera'] = ('pass' if v else 'fail') if type(v) is bool else 'unknown'
    rows = data.get('regions')
    if not isinstance(rows, list) or not rows:
        return {'controls': controls, 'regions': [], 'error': 'unknown:regions'}

    def compare(d, roi, kind, size, direction):
        if not isinstance(d, dict) or d.get('kind') != kind or d.get('roi') != roi:
            return None
        try:
            a = np.asarray([d['R6'], d['E']])
            if a.shape != (2, size) or a.dtype.kind not in 'iuf':
                return None
            if not np.isfinite(a).all() or np.any(a < 0):
                return None
            if direction == 1 and np.any(a > 1):
                return None
            better = (a[1] > a[0]) if direction == 1 else (a[1] < a[0])
            return np.where(a[1] == a[0], 'unchanged',
                            np.where(better, 'improved', 'regressed')).tolist()
        except (KeyError, TypeError, ValueError, OverflowError):
            return None

    out = []
    for i, row in enumerate(rows):
        r = row if isinstance(row, dict) else {}
        roi = r.get('roi')
        valid = isinstance(roi, list) and len(roi) == 4
        valid = valid and all(type(v) is int for v in roi)
        valid = valid and 0 <= roi[0] < roi[2] and 0 <= roi[1] < roi[3]
        c = compare(r.get('coverage'), roi, 'object_id_scene_depth_aa', 1, 1) if valid else None
        t = compare(r.get('texture'), roi, 'photo_error', 2, -1) if valid else None
        reasons = [s + ':' + k for k, s in controls.items() if s != 'pass']
        if not valid:
            reasons.append('unknown:roi')
        for name, values in [('coverage', c), ('texture', t)]:
            if values is None:
                reasons.append('unknown:' + name)
            elif 'regressed' in values:
                reasons.append(name + '_regression')
        failed = any(s.startswith('fail:') or s.endswith('_regression') for s in reasons)
        improved = 'improved' in (c or []) + (t or [])
        status = 'reject' if failed else ('unknown' if reasons else
                                         ('accept' if improved else 'unchanged'))
        ident = r.get('id') if isinstance(r.get('id'), str) else str(i)
        out.append({'id': ident, 'coverage': c if c is not None else 'unknown',
                    'texture': t if t is not None else 'unknown',
                    'status': status, 'reasons': reasons})
    return {'controls': controls, 'regions': out}
