import numpy as np


def check_sprig_similarity(d):
    """Read-only rooted proper-similarity check; coordinates in metres."""
    try:
        keys = ('wood0', 'wood1', 'leaves0', 'leaves1', 'fixed0', 'fixed1')
        w, W, l, L, f, F = [np.asarray(d[k], float) for k in keys]
        arrays = (w, W, l, L, f, F)
        if any(a.ndim != 2 or a.shape[1] != 3 or not len(a) for a in arrays):
            raise ValueError()
        if w.shape != W.shape or l.shape != L.shape or f.shape != F.shape:
            raise ValueError()
        r, R = np.asarray(d['root0'], float), np.asarray(d['root1'], float)
        if r.shape != (3,) or R.shape != (3,): raise ValueError()
        if not all(np.isfinite(a).all() for a in arrays + (r, R)): raise ValueError()
        p0, h0 = np.asarray(d['petioles']), np.asarray(d['support'])
        p, h = p0.astype(int), h0.astype(int)
        if p.ndim != 1 or not len(p) or h.shape != (len(p), 2): raise ValueError()
        if not np.array_equal(p, p0) or not np.array_equal(h, h0): raise ValueError()
        if len(np.unique(p)) != len(p) or np.any(p < 0) or np.any(p >= len(l)):
            raise ValueError()
        if np.any(h < 0) or np.any(h >= len(w)): raise ValueError()
        bounds = np.asarray(d.get('scale_bounds', [.97, 1.03]), float)
        tol, att = float(d.get('tol_m', 1e-5)), float(d.get('attachment_m', .003))
        if bounds.shape != (2,) or not np.isfinite(bounds).all(): raise ValueError()
        if not 0 < bounds[0] <= bounds[1] or not np.isfinite([tol, att]).all():
            raise ValueError()
        if tol <= 0 or att < 0: raise ValueError()
        x, y = np.vstack((w, l)) - r, np.vstack((W, L)) - r
        if not np.isfinite(x).all() or not np.isfinite(y).all(): raise ValueError()
        if min(np.linalg.matrix_rank(a, tol=1e-10*np.linalg.norm(a)) for a in (x, y)) < 2:
            return {'accepted': False, 'reason': 'degenerate_correspondences'}
        u, sv, vt = np.linalg.svd(x.T @ y)
        signs = np.array([1., 1., 1. if np.linalg.det(u @ vt) >= 0 else -1.])
        rotation = (u * signs) @ vt
        scale = float((sv @ signs) / np.sum(x*x))
        residual = np.linalg.norm(r + scale*(x @ rotation) - np.vstack((W, L)), axis=1)
        wm, lm = float(residual[:len(w)].max()), float(residual[len(w):].max())
        distances = []
        for wood, leaf in ((w, l), (W, L)):
            a, b = wood[h[:, 0]], wood[h[:, 1]]
            v = b-a; den = np.sum(v*v, axis=1)
            if np.any(den <= 1e-20): raise ValueError()
            t = np.clip(np.sum((leaf[p]-a)*v, axis=1)/den, 0, 1)
            distances.append(np.linalg.norm(leaf[p]-(a+t[:, None]*v), axis=1))
        drift = float(np.linalg.norm(R-r))
        socket = np.array([np.linalg.norm(r-f[0]), np.linalg.norm(R-f[0])])
        fixed = float(np.linalg.norm(F-f, axis=1).max())
        if not np.isfinite([scale, wm, lm, drift, fixed, *socket]).all(): raise ValueError()
        if not all(np.isfinite(a).all() for a in distances): raise ValueError()
        checks = {'root': drift <= tol, 'socket': bool(np.all(socket <= tol)),
                  'fixed': bool(np.array_equal(f, F)),
                  'scale': bool(scale > 0 and bounds[0]-1e-12 <= scale <= bounds[1]+1e-12),
                  'similarity': max(wm, lm) <= tol,
                  'attachment': bool(max(a.max() for a in distances) <= att)}
        return {'accepted': all(checks.values()), 'checks': checks,
                'rootDriftM': round(drift, 9), 'socketErrorM': np.round(socket, 9).tolist(),
                'fixedDriftM': round(fixed, 9), 'scale': round(scale, 9),
                'scaleBounds': bounds.tolist(),
                'nonrigidMaxM': {'wood': round(wm, 9), 'leaves': round(lm, 9)},
                'petioleDistanceM': {'original': np.round(distances[0], 9).tolist(),
                                     'new': np.round(distances[1], 9).tolist()}}
    except (KeyError, TypeError, ValueError, IndexError, OverflowError, np.linalg.LinAlgError):
        return {'accepted': False, 'reason': 'invalid_input'}
