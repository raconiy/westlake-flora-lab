import numpy as np


def regularize_branch(data):
    """One anchored curve mode; projected observations use pixels and px/metre."""
    q = np.empty((0, 3))
    def reject(reason):
        valid = q.ndim == 2 and q.shape[1] == 3 and np.isfinite(q).all()
        return {'accepted': False, 'reason': reason,
                'points': q.tolist() if valid else [], 'shift': [0, 0, 0]}
    try:
        q = np.asarray(data['points'], dtype=float)
        if q.ndim != 2 or q.shape[1] != 3 or len(q) < 3 or not np.isfinite(q).all():
            return reject('invalid_input')
        n = len(q)
        pivot = int(data['pivot'])
        raw_fixed = data['fixed']
        if pivot != data['pivot'] or any(int(i) != i for i in raw_fixed):
            return reject('invalid_input')
        fixed = sorted(set([0, n-1] + [int(i) for i in raw_fixed]))
        cap, ridge = float(data['cap']), float(data['ridge'])
        if not (np.isfinite([cap, ridge]).all() and cap > 0 and ridge > 0):
            return reject('invalid_input')
        if pivot < 0 or pivot >= n or fixed[0] < 0 or fixed[-1] >= n:
            return reject('invalid_input')
        if pivot in fixed:
            return reject('anchored_pivot')
        edges = np.diff(q, axis=0)
        lengths = np.linalg.norm(edges, axis=1)
        if np.any(lengths < 1e-9):
            return reject('degenerate_curve')
        s = np.r_[0., np.cumsum(lengths)]
        left = max(i for i in fixed if i < pivot)
        right = min(i for i in fixed if i > pivot)
        w = np.zeros(n)
        for i in range(left+1, right):
            u = ((s[i]-s[left])/(s[pivot]-s[left]) if i <= pivot
                 else (s[right]-s[i])/(s[right]-s[pivot]))
            w[i] = u*u*(3-2*u)
        records = []
        for o in data.get('observations', []):
            if o.get('visible') is not True or o.get('kind') != 'wood':
                continue
            c = float(o.get('confidence', 0))
            if not np.isfinite(c) or c < 0 or c > 1:
                return reject('invalid_input')
            if c < .5:
                continue
            i = int(o['index'])
            if i != o['index'] or not 0 <= i < n:
                return reject('invalid_input')
            j = np.asarray(o['jacobian'], float)
            b = np.asarray(o['target'], float)-np.asarray(o['uv'], float)
            view = o['view']
            if j.shape != (2, 3) or b.shape != (2,) or not isinstance(view, str) or not view:
                return reject('invalid_input')
            if not np.isfinite(j).all() or not np.isfinite(b).all():
                return reject('invalid_input')
            if w[i] > 0:
                records.append((view, np.sqrt(c)*w[i]*j, np.sqrt(c)*b))
        if len({r[0] for r in records}) < 2:
            return reject('missing_multiview')
        a = np.vstack([r[1] for r in records])
        b = np.concatenate([r[2] for r in records])
        if np.linalg.matrix_rank(a, tol=1e-7*max(1., np.linalg.norm(a, 2))) < 3:
            return reject('unobservable_depth')
        shift = np.linalg.solve(a.T@a+ridge*np.eye(3), a.T@b)
        size = np.linalg.norm(shift)
        shift *= min(1., cap/max(size, 1e-15))
        candidate = q+w[:, None]*shift
        bend = lambda x: np.linalg.norm(np.diff(x, n=2, axis=0), axis=1).sum()
        if bend(candidate)+1e-12 < .9*bend(q):
            return reject('bend_loss')
        new_edges = np.diff(candidate, axis=0)
        ratio = np.linalg.norm(new_edges, axis=1)/lengths
        if np.any((ratio < .75) | (ratio > 1.25)) or np.any(np.sum(edges*new_edges, axis=1) <= 0):
            return reject('edge_change')
        before, after = float(b@b), float(np.sum((a@shift-b)**2))
        for view in {r[0] for r in records}:
            old = sum(float(v@v) for k, j, v in records if k == view)
            new = sum(float(np.sum((j@shift-v)**2)) for k, j, v in records if k == view)
            if new > old+1e-10:
                return reject('view_regression')
        if not np.isfinite(candidate).all() or not after < before-1e-10:
            return reject('no_gain')
        return {'accepted': True, 'reason': 'ok', 'points': candidate.tolist(),
                'shift': shift.tolist(), 'maxUpdate': float(np.linalg.norm(shift)),
                'linearErrorBefore': round(before, 6), 'linearErrorAfter': round(after, 6)}
    except (KeyError, TypeError, ValueError, IndexError, np.linalg.LinAlgError):
        return reject('invalid_input')
