import numpy as np


def select_foliage(x):
    if not isinstance(x, dict): return {'ok': False, 'reason': 'invalid_input'}
    for key in ('blade_ids', 'areas_px2', 'density', 'footprint_px2'):
        if key not in x: return {'ok': False, 'reason': 'missing:' + key}
    try:
        ids = x['blade_ids']
        if not isinstance(ids, list) or any(type(i) is not int or not 0 <= i < 2**32 for i in ids): raise ValueError()
        n = len(ids); a = np.asarray(x['areas_px2'], dtype=float)
        allowed = x.get('allowed', [True] * n)
        if not isinstance(allowed, list) or len(allowed) != n or any(type(v) is not bool for v in allowed): raise ValueError()
        if a.shape != (n,) or not np.all(np.isfinite(a)) or np.any(a < 0) or len(set(ids)) != n: raise ValueError()
        d = float(x['density']); foot = float(x['footprint_px2'])
        h = float(x.get('hysteresis', .125)); feather = float(x.get('feather', .125))
        dt = float(x.get('dt', 1/60)); fade = float(x.get('fade_seconds', .2))
        if not all(np.isfinite(v) for v in (d, foot, h, feather, dt, fade)): raise ValueError()
        if not (0 <= d <= 1 and foot > 0 and 0 <= h <= .5 and 0 < feather <= .5 and dt >= 0 and fade > 0): raise ValueError()
        seed = x.get('seed', 0); previous = x.get('previous', {})
        if type(seed) is not int or not 0 <= seed < 2**32 or not isinstance(previous, dict): raise ValueError()
        order = np.argsort(ids)
        ids = [ids[int(i)] for i in order]; a = a[order]
        active = np.asarray(allowed, dtype=bool)[order] & (a > 0)
        raw = np.where(active, np.maximum(d, np.minimum(a, foot)/foot), 0)
        q = raw.copy(); old = np.zeros(n); seen = np.zeros(n, dtype=bool)
        for i, ident in enumerate(ids):
            state = previous.get(str(ident))
            if state is None: continue
            oq = float(state['q']); oa = float(state['alpha'])
            if not np.isfinite(oq) or not np.isfinite(oa) or not (0 <= oq <= 1 and 0 <= oa <= 1): raise ValueError()
            seen[i] = True; old[i] = oa
            if active[i]: q[i] = max(d, float(np.clip(oq, raw[i]-h, raw[i]+h)))
        q = np.clip(q, 0, 1)
        u = np.array([(((i*2654435761+seed) & 0xffffffff)+.5)/4294967296 for i in ids])
        band = np.minimum(feather, np.minimum(q, 1-q))
        t = np.clip((q-u)/(2*np.maximum(band, 1e-15))+.5, 0, 1)
        target = t*t*(3-2*t)*np.divide(d, q, out=np.zeros(n), where=q > 0)
        step = min(1., dt/fade)
        alpha = np.where(seen, old+np.clip(target-old, -step, step), target)
        alpha = np.where(active, np.clip(alpha, 0, 1), 0)
        requested = d*sum(float(v) for v in a[active])
        achieved = sum(float(v)*float(w) for v, w in zip(a, alpha))
        if not np.isfinite(requested) or not np.isfinite(achieved): raise ValueError()
        pick = np.flatnonzero(alpha > 0)
        return {'ok': True, 'selected_ids': [ids[int(i)] for i in pick],
                'alpha_weights': [float(alpha[i]) for i in pick],
                'state': {str(k): {'q': float(q[i]), 'alpha': float(alpha[i])} for i, k in enumerate(ids)},
                'mass_px2': {'requested': requested, 'achieved': achieved,
                             'deficit': max(0., requested-achieved),
                             'excess': max(0., achieved-requested)}}
    except (TypeError, ValueError, KeyError, OverflowError):
        return {'ok': False, 'reason': 'invalid_input'}
